
#include "common.h"
#include "elink_test.h"
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <net/if.h>

#define TEST_PUBLIC_KEY "-----BEGIN PUBLIC KEY-----\n"\
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCz9w7fTin0vJC02vb9rZpjx12\n"\
    "IFZf5ZqMXMNsjWrqiyVUrBB06pUCUTS4R9HkUOo+YEXy/F1+6/h+WBaUNGoLy9SJ\n"\
    "2jUTtcx4fXCES618YSy0KuedtZwImtKedmQRN2qJh/Vppiwv6MioxSKqUJQX3c2U\n"\
    "24bR1316vKfaoloz5QIDAQAB\n"\
    "-----END PUBLIC KEY-----\n"

#define REAL_PUBLIC_KEY "-----BEGIN PUBLIC KEY-----\n"\
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwKhuZ3bQD2DQFzap/5sT0cBtf\n"\
    "PTRd47Mih1ivZ/71YQbEeHFc1EDCfR1ryW3zhaBb8VWseXM2yo6NI1KvFWb3w3Hx\n"\
    "c2vOtq3pKO5R9jHezDLmRvdwNnxzYJa/o8sf9mQBGIIz/G7rhi2TZAeXseJeXAJ2\n"\
    "WXvsOEL9jBM/cA4rowIDAQAB\n"\
    "-----END PUBLIC KEY-----\n"

#define CHECK_JSON_VALUE(tmp,str) if(NULL == tmp) \
								{printf("json %s get error\n",str);    goto bad_message;	}

struct bksrv
{
    char *addr;
    unsigned int port;
    unsigned char used;
};

#define NUM_OF_BACKUP_SRV 4
struct srvcfg
{
    char *bssaddr;
    unsigned int bssport;
    char *addr;
    unsigned int port;
    struct bksrv backup[NUM_OF_BACKUP_SRV];
};

struct apcfg
{
    char *mac;
    char *vendor;
    char *model;
    char *swver;
    char *hdver;
    char *sn;
    char *ipaddr;
    char *gwmac;
};

struct devcfg
{
    char *token;
    char *id;
};

struct keyinfo
{
    unsigned char *shared_key;  //local dh/ecdh
    unsigned char *client_key;  //tcp CKey
    unsigned char *server_key;  //tcp SKey
    unsigned char *public_key;  //rsa public key
    char *challenge_code; //in Activate and Connect msg
};

struct cmd_info
{
    struct list_head list;
    char *content;
    unsigned short len;
};

struct req_info
{
    struct list_head list;
    char *raw;
    unsigned short len;
};

struct spp_info
{
    struct list_head list;
    unsigned int sequence;
    char *id;
    int  cur_index;
    struct uloop_timeout timer;
};

struct elink_ctx
{
    struct srvcfg server;
    struct apcfg ap;
    struct devcfg dev;
    struct keyinfo keys;
    struct ustream_fd local;
    struct ustream_fd remote;
    struct uloop_fd srv_fd;
    unsigned char is_bss;
    unsigned char is_bootstrap;
    char *curr_srv;
    char *msg; //fragment
    unsigned int curr_port;
    unsigned int sequence;
    unsigned int retry_count;
    unsigned int retry_cycle;
    struct list_head cmd_list; //local
    struct list_head req_list; //remote
    struct list_head spp_list; //SetPluginParams
};

struct elink_ctx g_elink_ctx;

enum elink_msg_type
{
    EMT_UNKNOWN = -1,
    EMT_KEYNGREQ,
    EMT_DH, EMT_ECDH,
    EMT_DEVREG, EMT_KEEPALIVE,
    EMT_ACK, EMT_STATUS,
    EMT_DEVREPORT, EMT_CFG,EMT_WANREPORT
};

typedef int (*msg_handler)(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf);
typedef int (*tail_check)(const char *msg);
typedef int (*add_to_list)(char *msg, int len);

unsigned int _get_retry_interval(unsigned int retry_count);

static void elink_local_read_cb(struct ustream *s, int bytes);
static void elink_local_notify_state(struct ustream *s);
int elink_cloud_client(void);
static void elink_remote_notify_state(struct ustream *s);

int _send_remote_msg(unsigned char *msg, int len);
int _send_local_msg(unsigned char *msg, int msg_len, int isdh);

void _heartbeat_tmot_cb(struct uloop_timeout *timeout);
void _remote_ack_tmot_cb(struct uloop_timeout *timeout);
void _local_ack_tmot_cb(struct uloop_timeout *timeout);
void _spp_ack_tmot_cb(struct uloop_timeout *timeout);
void _remote_connect_cb(struct uloop_timeout *timeout);
void _remote_disconnect_cb(struct uloop_timeout *timeout);
void _remote_action_cb(struct uloop_timeout *timeout);
void _local_action_cb(struct uloop_timeout *timeout);
int _process_local_msg(struct ustream *s, struct cmd_info *cmd, char *data, unsigned int len);
int _process_remote_msg(struct ustream *s, struct req_info *req, char *data, unsigned int len);
int _notify_ap_server(struct ustream *s, int ishb);
void _local_test_cb(struct uloop_timeout *timeout);
void _local_roaming_cb(struct uloop_timeout *timeout);
void _local_dev_report_cb(struct uloop_timeout *timeout);
void _local_deassociation_cb(struct uloop_timeout *timeout);
void _local_getrssinfo_cb(struct uloop_timeout *timeout);
static void elink_unix_server(void);

struct uloop_timeout heartbeat_timer = { .cb = _heartbeat_tmot_cb };
struct uloop_timeout remote_ack_timer = { .cb = _remote_ack_tmot_cb };
struct uloop_timeout local_ack_timer = { .cb = _local_ack_tmot_cb };
struct uloop_timeout remote_disconnect_timer = { .cb = _remote_disconnect_cb };
struct uloop_timeout remote_connect_timer = { .cb = _remote_connect_cb };
struct uloop_timeout remote_action_timer = { .cb = _remote_action_cb };
struct uloop_timeout local_action_timer = { .cb = _local_action_cb };
struct uloop_timeout local_test_timer = { .cb = _local_test_cb };
struct uloop_timeout local_roaming_timer = { .cb = _local_roaming_cb };
struct uloop_timeout local_deassociation_timer = { .cb = _local_deassociation_cb };
struct uloop_timeout local_dev_report_timer = { .cb = _local_dev_report_cb };
struct uloop_timeout local_getrssinfo_timer = { .cb = _local_getrssinfo_cb };

void _dump_list(int type)
{
#if ENABLE_LIST_DEBUG
    struct req_info *p = NULL;
    struct cmd_info *c = NULL;
    struct spp_info *s = NULL;
    int count = 0;

    if (type == 0)
    {
        list_for_each_entry(p, &g_elink_ctx.req_list, list)
        {
            count++;
        }
        ULOG_INFO("%d items in remote req list\n", count);
    }
    else if (type == 1)
    {
        list_for_each_entry(c, &g_elink_ctx.cmd_list, list)
        {
            count++;
        }
        ULOG_INFO("%d items in local cmd list\n", count);
    }
    else if (type == 2)
    {
        list_for_each_entry(s, &g_elink_ctx.spp_list, list)
        {
            count++;
        }
        ULOG_INFO("%d items in ssp list\n", count);
    }

#endif
    return;
}


int recv_ack_(cJSON*root)
{
	printf("\n  \033[;34m sucess!!!!  ,you need check next query \033[0m\n");
	return 0;
}

int check_24g_wifi(cJSON*root)
{
	int i = 0;
	int j = 0;
	int wifi_array_size = 0;
	cJSON *stats = NULL;
	cJSON *wifi_array = NULL;
	cJSON *tmp_array = NULL;
	cJSON *radio = NULL;
	cJSON *tmp = NULL;
	int ap_array_size = 0;
	cJSON *ap_array = NULL;
	cJSON *ap_tmp_array = NULL;
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wifi_array = cJSON_GetObjectItem(stats,"wifi");
	CHECK_JSON_VALUE(wifi_array,"wifi");
	wifi_array_size = cJSON_GetArraySize(wifi_array);
	for(i = 0;i < wifi_array_size;i++)
	{
		tmp_array = cJSON_GetArrayItem(wifi_array,i);
		CHECK_JSON_VALUE(tmp_array,"wifi_array");

		radio = cJSON_GetObjectItem(tmp_array,"radio");
		CHECK_JSON_VALUE(radio,"radio");
		
		tmp = cJSON_GetObjectItem(radio,"mode");
		CHECK_JSON_VALUE(tmp,"mode");
		if(0 == strcmp(tmp->valuestring,"2.4G"))
		{
			tmp = cJSON_GetObjectItem(radio,"channel");	
			CHECK_JSON_VALUE(tmp,"channel");
			if(tmp->valueint != 1)
			{
				printf("\n \033[;31m channel(%d)  error !!!!!!\n",tmp->valueint);
				goto bad_message;
			}
			tmp = cJSON_GetObjectItem(radio,"txpower");	
			CHECK_JSON_VALUE(tmp,"txpower");
			if(strcmp(tmp->valuestring,"0"))
			{
				printf("\n \033[;31m txpower(%s)  error !!!!!!\n",tmp->valuestring);
				goto bad_message;
			}
			ap_array = cJSON_GetObjectItem(tmp_array,"ap");
			CHECK_JSON_VALUE(ap_array,"ap");
			ap_array_size = cJSON_GetArraySize(ap_array);
			for(j = 0;j < ap_array_size;j++)
			{
				ap_tmp_array = cJSON_GetArrayItem(ap_array,j);
				CHECK_JSON_VALUE(ap_tmp_array,"ap_tmp_array");
				tmp = cJSON_GetObjectItem(ap_tmp_array,"apidx");
				CHECK_JSON_VALUE(tmp,"apidx");
				if(tmp->valueint == 0)
				{
					tmp = cJSON_GetObjectItem(ap_tmp_array,"enable");
					CHECK_JSON_VALUE(tmp,"enable");
					if(strcmp(tmp->valuestring,"yes"))
					{
						printf("\n \033[;31m enable(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"ssid");
					CHECK_JSON_VALUE(tmp,"ssid");
					if(strcmp(tmp->valuestring,"aaaaaa123"))
					{
						printf("\n \033[;31m ssid(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"key");
					CHECK_JSON_VALUE(tmp,"key");
					if(strcmp(tmp->valuestring,"12345678"))
					{
						printf("\n \033[;31m key(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"auth");
					CHECK_JSON_VALUE(tmp,"auth");
					if(strcmp(tmp->valuestring,"wpapskwpa2psk"))
					{
						printf("\n \033[;31m auth(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"encrypt");
					CHECK_JSON_VALUE(tmp,"encrypt");
					if(strcmp(tmp->valuestring,"aes"))
					{
						printf("\n \033[;31m encrypt(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}

					printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
					return 0;
					
				}

			}
			
		}
	}
	
bad_message:
	printf("\n \033[;31mtest fail:config is error \033[0m\n");
	return 1;
}


int check_5g_wifi(cJSON*root)
{
	int i = 0;
	int j = 0;
	int wifi_array_size = 0;
	cJSON *stats = NULL;
	cJSON *wifi_array = NULL;
	cJSON *tmp_array = NULL;
	cJSON *radio = NULL;
	cJSON *tmp = NULL;
	int ap_array_size = 0;
	cJSON *ap_array = NULL;
	cJSON *ap_tmp_array = NULL;
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wifi_array = cJSON_GetObjectItem(stats,"wifi");
	CHECK_JSON_VALUE(wifi_array,"wifi");
	wifi_array_size = cJSON_GetArraySize(wifi_array);
	for(i = 0;i < wifi_array_size;i++)
	{
		tmp_array = cJSON_GetArrayItem(wifi_array,i);
		CHECK_JSON_VALUE(tmp_array,"wifi_array");

		radio = cJSON_GetObjectItem(tmp_array,"radio");
		CHECK_JSON_VALUE(radio,"radio");
		
		tmp = cJSON_GetObjectItem(radio,"mode");
		CHECK_JSON_VALUE(tmp,"mode");
		if(0 == strcmp(tmp->valuestring,"5G"))
		{
			tmp = cJSON_GetObjectItem(radio,"channel");	
			CHECK_JSON_VALUE(tmp,"channel");
			if(tmp->valueint != 36)
			{
				printf("\n \033[;31m channel(%d)  error !!!!!!\033[0m\n",tmp->valueint);
				goto bad_message;
			}
			tmp = cJSON_GetObjectItem(radio,"txpower");	
			CHECK_JSON_VALUE(tmp,"txpower");
			if(strcmp(tmp->valuestring,"0"))
			{
				printf("\n \033[;31m txpower(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
				goto bad_message;
			}
			ap_array = cJSON_GetObjectItem(tmp_array,"ap");
			CHECK_JSON_VALUE(ap_array,"ap");
			ap_array_size = cJSON_GetArraySize(ap_array);
			for(j = 0;j < ap_array_size;j++)
			{
				ap_tmp_array = cJSON_GetArrayItem(ap_array,j);
				CHECK_JSON_VALUE(ap_tmp_array,"ap_tmp_array");
				tmp = cJSON_GetObjectItem(ap_tmp_array,"apidx");
				CHECK_JSON_VALUE(tmp,"apidx");
				if(tmp->valueint == 0)
				{
					tmp = cJSON_GetObjectItem(ap_tmp_array,"enable");
					CHECK_JSON_VALUE(tmp,"enable");
					if(strcmp(tmp->valuestring,"yes"))
					{
						printf("\n \033[;31m enable(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"ssid");
					CHECK_JSON_VALUE(tmp,"ssid");
					if(strcmp(tmp->valuestring,"aaaaaa123_5G"))
					{
						printf("\n \033[;31m ssid(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"key");
					CHECK_JSON_VALUE(tmp,"key");
					if(strcmp(tmp->valuestring,"12345678"))
					{
						printf("\n \033[;31m key(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"auth");
					CHECK_JSON_VALUE(tmp,"auth");
					if(strcmp(tmp->valuestring,"wpapskwpa2psk"))
					{
						printf("\n \033[;31m auth(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}
					tmp = cJSON_GetObjectItem(ap_tmp_array,"encrypt");
					CHECK_JSON_VALUE(tmp,"encrypt");
					if(strcmp(tmp->valuestring,"aes"))
					{
						printf("\n \033[;31m encrypt(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
						goto bad_message;
					}

					printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
					return 0;
					
				}

			}
			
		}
	}
	
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_wifi_timer(cJSON*root)
{
	int i = 0;
	int wifi_array_size = 0;
	cJSON *stats = NULL;
	cJSON *wifi_array = NULL;
	cJSON *tmp_array = NULL;
	cJSON *tmp = NULL;
	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wifi_array = cJSON_GetObjectItem(stats,"wifitimer");
	CHECK_JSON_VALUE(wifi_array,"wifitimer");
	wifi_array_size = cJSON_GetArraySize(wifi_array);
	for(i = 0;i < wifi_array_size;i++)
	{
		tmp_array = cJSON_GetArrayItem(wifi_array,i);
		CHECK_JSON_VALUE(tmp_array,"wifitimer_array");

		tmp = cJSON_GetObjectItem(tmp_array,"weekday");
		CHECK_JSON_VALUE(tmp,"weekday");
		if(i == 0 && strcmp(tmp->valuestring,"1"))
		{
			printf("\n \033[;31m weekday(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}
		
		if(i == 1 && strcmp(tmp->valuestring,"2"))
		{
			printf("\n \033[;31m weekday(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}
		
		tmp = cJSON_GetObjectItem(tmp_array,"time");
		CHECK_JSON_VALUE(tmp,"time");
		if(strcmp(tmp->valuestring,"17:30"))
		{
			printf("\n \033[;31m time(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}

		tmp = cJSON_GetObjectItem(tmp_array,"enable");
		CHECK_JSON_VALUE(tmp,"enable");
		if(i == 0 && strcmp(tmp->valuestring,"0"))
		{
			printf("\n \033[;31m enable(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}

		if(i == 1 && strcmp(tmp->valuestring,"1"))
		{
			printf("\n \033[;31m enable(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}
		printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
		return 0;
	}
	
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_wifi_switch_off(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *wifi_array = NULL;
	cJSON *tmp_state = NULL;

	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wifi_array = cJSON_GetObjectItem(stats,"wifiswitch");
	CHECK_JSON_VALUE(wifi_array,"wifiswitch");
	tmp_state = cJSON_GetObjectItem(wifi_array,"status");
	CHECK_JSON_VALUE(tmp_state,"status");

	if(strcmp(tmp_state->valuestring,"OFF"))
	{
		printf("\n \033[;31m status(%s)  error !!!!!!\033[0m\n",tmp_state->valuestring);
		goto bad_message;
	}	
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_wifi_switch_on(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *wifi_array = NULL;
	cJSON *tmp_state = NULL;

	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wifi_array = cJSON_GetObjectItem(stats,"wifiswitch");
	CHECK_JSON_VALUE(wifi_array,"wifiswitch");
	tmp_state = cJSON_GetObjectItem(wifi_array,"status");
	CHECK_JSON_VALUE(tmp_state,"status");

	if(strcmp(tmp_state->valuestring,"ON"))
	{
		printf("\n \033[;31m status(%s)  error !!!!!!\033[0m\n",tmp_state->valuestring);
		goto bad_message;
	}	
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}


int check_led_switch_off(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *led_array = NULL;
	cJSON *tmp_state = NULL;

	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	led_array = cJSON_GetObjectItem(stats,"ledswitch");
	CHECK_JSON_VALUE(led_array,"ledswitch");
	tmp_state = cJSON_GetObjectItem(led_array,"status");
	CHECK_JSON_VALUE(tmp_state,"status");

	if(strcmp(tmp_state->valuestring,"OFF"))
	{
		printf("\n \033[;31m status(%s)  error !!!!!!\033[0m\n",tmp_state->valuestring);
		goto bad_message;
	}	
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_led_switch_on(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *led_array = NULL;
	cJSON *tmp_state = NULL;

	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	led_array = cJSON_GetObjectItem(stats,"ledswitch");
	CHECK_JSON_VALUE(led_array,"ledswitch");
	tmp_state = cJSON_GetObjectItem(led_array,"status");
	CHECK_JSON_VALUE(tmp_state,"status");

	if(strcmp(tmp_state->valuestring,"ON"))
	{
		printf("\n \033[;31m status(%s)  error !!!!!!\033[0m\n",tmp_state->valuestring);
		goto bad_message;
	}	
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_bandsupport(cJSON*root)
{
	int i = 0;
	int band_num = 0;
	cJSON *stats = NULL;
	cJSON *band_array = NULL;
	cJSON *tmp = NULL;

	
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	band_array = cJSON_GetObjectItem(stats,"bandsupport");
	CHECK_JSON_VALUE(band_array,"bandsupport");
	band_num = cJSON_GetArraySize(band_array);

	for(i = 0;i < band_num;i++)
	{
		tmp = cJSON_GetArrayItem(band_array,i);
		if(i == 0 && strcmp(tmp->valuestring,"2.4G"))
		{
			printf("\n \033[;31m band_array(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}
		if(i == 1 && strcmp(tmp->valuestring,"5G"))
		{
			printf("\n \033[;31m band_array(%s)  error !!!!!!\033[0m\n",tmp->valuestring);
			goto bad_message;
		}
	}
	
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_cpureta(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *cpurate = NULL;
	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	cpurate = cJSON_GetObjectItem(stats,"cpurate");
	CHECK_JSON_VALUE(cpurate,"cpurate");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_memreta(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *memoryuserate = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	memoryuserate = cJSON_GetObjectItem(stats,"memoryuserate");
	CHECK_JSON_VALUE(memoryuserate,"memoryuserate");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_uploadreta(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *uploadspeed = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	uploadspeed = cJSON_GetObjectItem(stats,"uploadspeed");
	CHECK_JSON_VALUE(uploadspeed,"uploadspeed");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}
int check_dowloadreta(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *downloadspeed = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	downloadspeed = cJSON_GetObjectItem(stats,"downloadspeed");
	CHECK_JSON_VALUE(downloadspeed,"downloadspeed");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_wlanstats(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *wlanstats = NULL;
	char *str = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	wlanstats = cJSON_GetObjectItem(stats,"wlanstats");
	CHECK_JSON_VALUE(wlanstats,"wlanstats");
	str = cJSON_Print(wlanstats);
	CHECK_JSON_VALUE(str,"wlanstats");
	if(NULL == strstr(str,"totalBytesSent"))
	{
		printf("\n \033[;31m wlanstats(%s)  error !!!!!!\033[0m\n",str);
		goto bad_message;
	}
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}


int check_channel(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *channel = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	channel = cJSON_GetObjectItem(stats,"channel");
	CHECK_JSON_VALUE(channel,"channel");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_onlineTime(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *onlineTime = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	onlineTime = cJSON_GetObjectItem(stats,"onlineTime");
	CHECK_JSON_VALUE(onlineTime,"onlineTime");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_terminalNum(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *terminalNum = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	terminalNum = cJSON_GetObjectItem(stats,"terminalNum");
	CHECK_JSON_VALUE(terminalNum,"terminalNum");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_load(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *load = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	load = cJSON_GetObjectItem(stats,"load");
	CHECK_JSON_VALUE(load,"load");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_dev_info(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *real_devinfo = NULL;
	char *str = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	real_devinfo = cJSON_GetObjectItem(stats,"real_devinfo");
	CHECK_JSON_VALUE(real_devinfo,"real_devinfo");
	str = cJSON_Print(real_devinfo);
	CHECK_JSON_VALUE(str,"real_devinfo");
	if(NULL == strstr(str,"connecttype"))
	{
		printf("\n \033[;31m wlanstats(%s)  error !!!!!!\033[0m\n",str);
		goto bad_message;
	}
	if(NULL == strstr(str,"rssi"))
	{
		printf("\n \033[;31m wlanstats(%s)  error !!!!!!\033[0m\n",str);
		goto bad_message;
	}
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_neighborinfo(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *neighborinfo = NULL;
	char *str = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	neighborinfo = cJSON_GetObjectItem(stats,"neighborinfo");
	CHECK_JSON_VALUE(neighborinfo,"neighborinfo");
	str = cJSON_Print(neighborinfo);
	CHECK_JSON_VALUE(str,"neighborinfo");
	if(NULL == strstr(str,"rfband"))
	{
		printf("\n \033[;31m rfband(%s)  error !!!!!!\033[0m\n",str);
		goto bad_message;
	}
	if(NULL == strstr(str,"ssidname"))
	{
		printf("\n \033[;31m ssidname(%s)  error !!!!!!\033[0m\n",str);
		goto bad_message;
	}
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_elinkstat(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *elinkstat = NULL;
	cJSON *connectedGateway = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	elinkstat = cJSON_GetObjectItem(stats,"elinkstat");
	CHECK_JSON_VALUE(elinkstat,"elinkstat");
	connectedGateway = cJSON_GetObjectItem(elinkstat,"connectedGateway");
	CHECK_JSON_VALUE(connectedGateway,"connectedGateway");
	if(strcmp(connectedGateway->valuestring,"yes"))
	{
		printf("\n \033[;31m band_array(%s)  error !!!!!!\033[0m\n",connectedGateway->valuestring);
		goto bad_message;
	}
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_networktype(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *networktype = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	networktype = cJSON_GetObjectItem(stats,"networktype");
	CHECK_JSON_VALUE(networktype,"networktype");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int check_workmode(cJSON*root)
{
	cJSON *stats = NULL;
	cJSON *workmode = NULL;

	stats = cJSON_GetObjectItem(root,"status");
	CHECK_JSON_VALUE(stats,"status");
	workmode = cJSON_GetObjectItem(stats,"workmode");
	CHECK_JSON_VALUE(workmode,"workmode");
	printf("\n \033[;34m current item sucess !!!!!! \033[0m\n");
	return 0;
bad_message:
	printf("\n \033[;31m test fail:config is error \033[0m\n");
	return 1;
}

int recv_roaming_set_(cJSON*root)
{
	uloop_timeout_set(&local_roaming_timer, ELINKCC_60S_INTERVAL);
	printf("\n  \033[;34m sucess!!!!  ,you need check next query \033[0m\n");
	return 0;
}

TEST_INFO item_array[] = 
{
	{1,EXEC_SET_24G_WIFI	,CMD_SET_24G_WIFI	,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_24G_WIFI	,CMD_GET_24G_WIFI	,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_24g_wifi},
	{1,EXEC_SET_5G_WIFI		,CMD_SET_5G_WIFI	,ELINKCC_5S_INTERVAL  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_5G_WIFI		,CMD_GET_5G_WIFI	,ELINKCC_10S_INTERVAL  	,ELINKCC_100MS_INTERVAL,check_5g_wifi},
	{1,EXEC_SET_WIFI_TIMER	,CMD_SET_WIFI_TIMER	,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_WIFI_TIMER	,CMD_GET_WIFI_TIMER	,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_wifi_timer},
	{1,EXEC_WIFISWITCH_OFF	,CMD_WIFISWITCH_OFF,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_WIFISWITCH	,CMD_GET_WIFISWITCH,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_wifi_switch_off},
	{1,EXEC_WIFISWITCH_ON	,CMD_WIFISWITCH_ON	,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_WIFISWITCH	,CMD_GET_WIFISWITCH,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_wifi_switch_on},
	{1,EXEC_LEDSWITCH_OFF	,CMD_LEDSWITCH_OFF	,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_LEDSWITCH	,CMD_GET_LEDSWITCH	,ELINKCC_5S_INTERVAL	  	,ELINKCC_100MS_INTERVAL,check_led_switch_off},
	{1,EXEC_LEDSWITCH_ON	,CMD_LEDSWITCH_ON	,ELINKCC_5S_INTERVAL	  	,ELINKCC_45S_INTERVAL,recv_ack_},
	{1,EXEC_GET_LEDSWITCH	,CMD_GET_LEDSWITCH	,ELINKCC_5S_INTERVAL	  	,ELINKCC_100MS_INTERVAL,check_led_switch_on},
	{1,EXEC_GET_WIFI_TIMER	,CMD_GET_WIFI_TIMER	,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_wifi_timer},
	{1,EXEC_BANDSUPPORT	,CMD_BANDSUPPORT	,ELINKCC_10S_INTERVAL 	,ELINKCC_100MS_INTERVAL,check_bandsupport},
	{1,EXEC_CPURATE			,CMD_CPURATE		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_cpureta},
	{1,EXEC_MEMRATE			,CMD_MEMRATE		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_memreta},
	{1,EXEC_UPLOADSPEED		,CMD_UPLOADSPEED	,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_uploadreta},
	{1,EXEC_DOWNLOADSPEED	,CMD_DOWNLOADSPEED,ELINKCC_5S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_dowloadreta},
	{1,EXEC_WLANSTATS		,CMD_WLANSTATS		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_wlanstats},
	{1,EXEC_CHANNEL			,CMD_CHANNEL		,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_channel},
	{1,EXEC_ONLINETIME		,CMD_ONLINETIME		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_onlineTime},
	{1,EXEC_TERMINALNUM		,CMD_TERMINALNUM	,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_terminalNum},
	{1,EXEC_LOAD			,CMD_LOAD			,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_load},
	{1,EXEC_REALDEVINFO		,CMD_REALDEVINFO	,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_dev_info},
	{1,EXEC_ELINKSTAT		,CMD_ELINKSTAT		,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_elinkstat},
	{1,EXEC_NEIGHBORINFO	,CMD_NEIGHBORINFO	,ELINKCC_10S_INTERVAL	,ELINKCC_100MS_INTERVAL,check_neighborinfo},
	{1,EXEC_NETWORKTYPE	,CMD_NETWORKTYPE	,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_networktype},
	{1,EXEC_WORKMODE		,CMD_WORKMODE		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_workmode},
	{1,EXEC_CPURATE			,CMD_CPURATE		,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,check_cpureta},
	{1,EXEC_WPS_ON			,CMD_WPS_ON		,ELINKCC_15S_INTERVAL	,ELINKCC_100MS_INTERVAL,recv_ack_},
	{1,EXEC_ROAMING_SET		,CMD_ROAMING_SET	,ELINKCC_5S_INTERVAL		,ELINKCC_100MS_INTERVAL,recv_roaming_set_},
};


void init_test_config()
{
	int i = 0;
	int test_all = 1;
	printf("test item:\n");
	for(i = 0;i < ARRAY_SIZE(item_array);i++)
	{
		printf("%d:  %.20s\n",i,item_array[i].item_name);
	}
}

int get_current_index(int index)
{
	int i = -1;
	for(i = index;i <ARRAY_SIZE(item_array);i++ )
	{
		if(item_array[i].test_enable == 1)
			break;
	}
	return i;
}

void send_local_test(int index)
{
	char new_json[1024 * 8] = {0};
	int json_len = 0;
	struct spp_info *si = NULL;
	int cur_index = 0;
	cur_index = get_current_index(index);

	if(cur_index == -1)
	{
		printf("-----------------------test  over------------------------\n");
		return ;
	}
	/* setup ID/sequence mapping */
	/* freed in _handler_ack and _spp_ack_tmot_cb */
	si = calloc(1, sizeof(struct spp_info));

	if (si)
	{
		si->sequence = g_elink_ctx.sequence;
		si->id = strdup("123");
		si->timer.cb = _spp_ack_tmot_cb;
		si->cur_index = cur_index;
		list_add_tail(&si->list, &g_elink_ctx.spp_list);
		_dump_list(2);
		//printf("link id %s and sequence %d\n", si->id, si->sequence);
	}
	else
	{
		printf("%d: failed to malloc spp_info\n", __LINE__);
		goto done;
	}
	json_len = sprintf(new_json,item_array[cur_index].item_value,g_elink_ctx.sequence++,g_elink_ctx.ap.mac);
	printf("\n\ncur_test_intem:      %s\n",item_array[cur_index].item_name);
	printf("(local) -> %s (%d)\n", new_json, json_len);
	_send_local_msg((unsigned char *)new_json, json_len, 0);
	uloop_timeout_set(&si->timer, item_array[cur_index].timeout);
done:
	return;
}

void _local_test_cb(struct uloop_timeout *timeout)
{
	send_local_test(timeout->index);
}

void _local_roaming_cb(struct uloop_timeout *timeout)
{
	printf("\n  \033[;31m fail roaming report!!!!   \033[0m\n");
}

char mac_list[16]  = {0};
char del_mac_list[16]  = {0};
char getrssi_mac_list[16]  = {0};
void _local_dev_report_cb(struct uloop_timeout *timeout)
{
	printf("\n  \033[;31m fail deassociation dev_report!!!!   \033[0m\n");
}


void _local_deassociation_cb(struct uloop_timeout *timeout)
{
	char new_json[1024 * 8] = {0};
	int json_len = 0;
	struct spp_info *si = NULL;
	int cur_index = 0;

	strcpy(del_mac_list,mac_list);
	strcpy(getrssi_mac_list,del_mac_list);
 	json_len = sprintf(new_json,"{\"type\":\"deassociation\",\"sequence\":%d,\"mac\":\"%s\",\"set\":{\"mac\":[\"%s\"]}}",g_elink_ctx.sequence++,g_elink_ctx.ap.mac,mac_list);
	printf("\n\ncur_test_intem:      deassociation\n");
	printf("(local) -> %s (%d)\n", new_json, json_len);
	_send_local_msg((unsigned char *)new_json, json_len, 0);
	uloop_timeout_set(&local_dev_report_timer, ELINKCC_60S_INTERVAL);

}

void send_getrssinfo()
{
	char new_json[1024 * 8] = {0};
	int json_len = 0;
	struct spp_info *si = NULL;
	int cur_index = 0;

 	json_len = sprintf(new_json,CMD_GETRSSIINFO,g_elink_ctx.sequence++,g_elink_ctx.ap.mac,getrssi_mac_list);
	printf("\n\ncur_test_intem:      getrssinfo\n");
	printf("(local) -> %s (%d)\n", new_json, json_len);
	_send_local_msg((unsigned char *)new_json, json_len, 0);
	uloop_timeout_set(&local_getrssinfo_timer, ELINKCC_60S_INTERVAL);

}

void _local_getrssinfo_cb(struct uloop_timeout *timeout)
{
	printf("\n  \033[;31m fail deassociation dev_report!!!!   \033[0m\n");
}
int start_test_process(void)
{
    send_local_test(0);
    return 0;
}

static void public_key_init()
{
    FILE *fp = NULL;
    int len = 0, cnt = 0;

#if USE_LOCAL_BSS_SERVER
    ULOG_DEBUG("use test pem\n");
    g_elink_ctx.keys.public_key = (unsigned char *)strdup(TEST_PUBLIC_KEY);
    return;
#endif

    if (access(ELINKCC_PEM, F_OK) != 0)
    {
        ULOG_DEBUG("%s doesn't exist, use default pem\n", ELINKCC_PEM);
        g_elink_ctx.keys.public_key = (unsigned char *)strdup(REAL_PUBLIC_KEY);

        fp = fopen(ELINKCC_PEM, "w");

        if (fp)
        {
            fwrite(REAL_PUBLIC_KEY, 1, strlen(REAL_PUBLIC_KEY), fp);
            fclose(fp);
        }
        else
        {
            ULOG_ERR("open pem error\n");
        }
    }
    else
    {
        fp = fopen(ELINKCC_PEM, "r");

        if (fp)
        {
            fseek(fp, 0, SEEK_END);
            len = ftell(fp);
            rewind(fp);
            g_elink_ctx.keys.public_key = malloc(len);
            cnt = fread(g_elink_ctx.keys.public_key, 1, len, fp);
            fclose(fp);
        }
        else
        {
            ULOG_ERR("open pem error\n");
        }

        if (cnt != len)
            ULOG_ERR("read pem error\n");
    }
}

int _set_backup_servers(char *server, int port, int idx)
{
    cJSON *root = NULL, *aobj = NULL, *array = NULL;
    cJSON *item = NULL;
    char *content = NULL;
    FILE *fp = NULL;

    root = _config_to_jobj(ELINKCC_CONFIG);

    if (!root)
        root = cJSON_CreateObject();

    if (!root)
    {
        ULOG_ERR("failed to create json obj\n");
        return -1;
    }

    item = cJSON_GetObjectItem(root, "Backup");

    if (idx == 0)
    {
        if (item)
            cJSON_DeleteItemFromObject(root, "Backup");

        cJSON_AddItemToObject(root, "Backup", array = cJSON_CreateArray());
    }
    else
    {
        array = item;
    }

    cJSON_AddItemToArray(array, aobj = cJSON_CreateObject());

    cJSON_AddItemToObject(aobj, "ServerAddr", cJSON_CreateString(server));
    cJSON_AddItemToObject(aobj, "ServerPort", cJSON_CreateNumber(port));

    content = cJSON_PrintUnformatted(root);
#if ENABLE_JSON_DEBUG
    ULOG_DEBUG("new config: %s\n", content);
#endif

    if (!content)
    {
        ULOG_ERR("config is not valid json\n");
        return -1;
    }

    fp = fopen(ELINKCC_CONFIG, "w+");

    if (fp)
    {
        fputs(content, fp);
        fclose(fp);
    }
    else
    {
        ULOG_ERR("failed to update %s\n", ELINKCC_CONFIG);
    }

    cJSON_free(content);
    cJSON_Delete(root);

    return 0;
}


static int _set_key_value(char *key, int type, char *sval, int ival)
{
    cJSON *obj = NULL;
    cJSON *item = NULL;
    char *content = NULL;
    FILE *fp = NULL;

    obj = _config_to_jobj(ELINKCC_CONFIG);

    if (!obj)
        obj = cJSON_CreateObject();

    if (!obj)
    {
        ULOG_ERR("failed to create json obj\n");
        return -1;
    }

    item = cJSON_GetObjectItem(obj, key);

    if (item)   //modify
    {
        if (type == cJSON_Number)
        {
            cJSON_SetNumberValue(item, ival);
        }
        else if (type == cJSON_String)
        {
            cJSON_DeleteItemFromObject(obj, key);
            cJSON_AddItemToObject(obj, key, cJSON_CreateString(sval));
        }
    }
    else     //add
    {
        if (type == cJSON_Number)
        {
            cJSON_AddItemToObject(obj, key, cJSON_CreateNumber(ival));
        }
        else if (type == cJSON_String)
        {
            cJSON_AddItemToObject(obj, key, cJSON_CreateString(sval));
        }
    }

    content = cJSON_PrintUnformatted(obj);

#if ENABLE_JSON_DEBUG
    ULOG_DEBUG("new config: %s\n", content);
#endif

    if (!content)
    {
        ULOG_ERR("config is not valid json\n");
        return -1;
    }

    fp = fopen(ELINKCC_CONFIG, "w+");

    if (fp)
    {
        fputs(content, fp);
        fclose(fp);
    }
    else
    {
        ULOG_ERR("failed to update %s\n", ELINKCC_CONFIG);
    }

    cJSON_free(content);
    cJSON_Delete(obj);

    return 0;
}


int _get_gateway_ipaddr(char **gw_ip)
{
    int sock = 0, rcv_bytes = 0, msg_len = 0, route_attr_len = 0;
    char ipstr[INET_ADDRSTRLEN] = {0};
    char sndbuf[sizeof(struct nlmsghdr)] = {0}, rcvbuf[4096] = {0};
    char *ptr = rcvbuf;
    struct nlmsghdr *nlh, *nlmsg;
    struct rtmsg *route_entry;
    struct rtattr *route_attr;
    struct timeval tv;

    sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);

    if (sock < 0)
        return sock;

    nlmsg = (struct nlmsghdr *)sndbuf;

    nlmsg->nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
    nlmsg->nlmsg_type = RTM_GETROUTE;
    nlmsg->nlmsg_flags = NLM_F_DUMP | NLM_F_REQUEST;
    nlmsg->nlmsg_seq = 1;
    nlmsg->nlmsg_pid = getpid();

    tv.tv_sec = 1;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (struct timeval *)&tv, sizeof(struct timeval));

    if (send(sock, nlmsg, nlmsg->nlmsg_len, 0) < 0)
    {
        perror("send failed");
        return EXIT_FAILURE;
    }

    do
    {
        rcv_bytes = recv(sock, ptr, sizeof(rcvbuf) - msg_len, 0);

        if (rcv_bytes < 0)
        {
            perror("Error in recv");
            return EXIT_FAILURE;
        }

        nlh = (struct nlmsghdr *) ptr;

        if ((NLMSG_OK(nlh, rcv_bytes) == 0) || (nlh->nlmsg_type == NLMSG_ERROR))
        {
            perror("Error in received packet");
            return EXIT_FAILURE;
        }

        if (nlh->nlmsg_type == NLMSG_DONE)
        {
            break;
        }
        else
        {
            ptr += rcv_bytes;
            msg_len += rcv_bytes;
        }

        if ((nlh->nlmsg_flags & NLM_F_MULTI) == 0)
            break;
    }
    while ((nlh->nlmsg_seq != nlmsg->nlmsg_seq) || (nlh->nlmsg_pid != nlmsg->nlmsg_pid));

    for (; NLMSG_OK(nlh, rcv_bytes); nlh = NLMSG_NEXT(nlh, rcv_bytes))
    {
        route_entry = (struct rtmsg *) NLMSG_DATA(nlh);
        route_attr = (struct rtattr *) RTM_RTA(route_entry);
        route_attr_len = RTM_PAYLOAD(nlh);

        for (; RTA_OK(route_attr, route_attr_len); route_attr = RTA_NEXT(route_attr, route_attr_len))
        {
            if (route_attr->rta_type == RTA_GATEWAY)
            {
                inet_ntop(AF_INET, RTA_DATA(route_attr), ipstr, sizeof(ipstr));
                *gw_ip = strdup(ipstr);
                //ULOG_DEBUG("gateway ip is %s\n", *gw_ip);
                break;
            }
        }

        if (*gw_ip)
            break;
    }

    close(sock);
    return 0;
}


void _get_gateway_mac(void)
{
    char *gw_ip = NULL;
    FILE *fp = NULL;
    char buf[128] = {0}, ipstr[INET_ADDRSTRLEN] = {0}, macstr[18] = {0};
    unsigned char mac[6] = {0};

    FREE(g_elink_ctx.ap.gwmac);
    _get_gateway_ipaddr(&gw_ip);

    if (!gw_ip)
        return;

    fp = fopen("/proc/net/arp", "r");

    if (!fp)
    {
        free(gw_ip);
        return;
    }

    while (fgets(buf, sizeof buf, fp))
    {
        if (sscanf(buf, "%15[^ ] %*[^ ] %*[^ ] %17[^ ] %*[^ ] %*[^ ]", ipstr, macstr) == 2)
        {
            //printf("ip: %s, mac: %s, gw_ip: %s\n", ipstr, macstr, gw_ip);

            if (strcmp(gw_ip, ipstr))
                continue;

            if (sscanf(macstr, "%02x:%02x:%02x:%02x:%02x:%02x",
                       (unsigned int *)&mac[0], (unsigned int *)&mac[1], (unsigned int *)&mac[2],
                       (unsigned int *)&mac[3], (unsigned int *)&mac[4], (unsigned int *)&mac[5]) == 6)
            {
                if (asprintf(&g_elink_ctx.ap.gwmac, "%02X%02X%02X%02X%02X%02X",
                             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]) < 0)
                    ULOG_ERR("failed to print gwmac\n");
            }

            break;
        }
        else
        {
            ULOG_ERR("failed to parse: %s", buf);
        }
    }

    //ULOG_DEBUG("gateway mac is %s\n", g_elink_ctx.ap.gwmac);

    fclose(fp);
    free(gw_ip);
}


int _handle_keyngreq(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int ret = 0, cnt = 0, i = 0;
    char *mac = NULL, *keymode = NULL;
    int sequence = 0;
    cJSON *kmlist = NULL;
    cJSON *item = NULL, *km = NULL;

    ret = _get_string_json_value(obj, "mac", &mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in keyngreq msg\n");
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in keyngreq msg\n");
        goto done;
    }

    kmlist = cJSON_GetObjectItem(obj, "keymodelist");

    if (cJSON_IsArray(kmlist))
    {

        json_array_foreach(kmlist, i, item)
        {
            km = cJSON_GetObjectItem(item, "keymode");

            if (!km)
                continue;

            if (_strcmp("ecdh", json_string_value(km)) == 0)
            {
                keymode = "ecdh";
                break;
            }
            else if (_strcmp("dh", json_string_value(km)) == 0)
            {
                keymode = "dh";
                break;
            }
        }

    }
    else
    {
        ULOG_ERR("no keymodelist in keyngreq msg\n");
    }

    if (keymode)
        cnt = asprintf((char **)rsp_buf, "{\"type\":\"keyngack\",\"sequence\":%d,\"mac\":\"%s\",\"keymode\":\"%s\"}",
                       sequence, mac, keymode);

done:
    FREE(mac);
    return cnt;
}


int _gen_dh_shared_key(BIO *out, BIGNUM *clipub, DH *server)
{
    int ret = 0;
    int len = DH_size(server);

    g_elink_ctx.keys.shared_key = (unsigned char *)malloc(len + 1);

    if (g_elink_ctx.keys.shared_key == NULL)
    {
        ULOG_ERR("Failed to malloc shared key\n");
        return -1;
    }
    else
    {
        memset(g_elink_ctx.keys.shared_key, 0, len + 1);
    }

    ret = DH_compute_key(g_elink_ctx.keys.shared_key, clipub, server);

    if (ret < 0)
    {
        FREE(g_elink_ctx.keys.shared_key);
    }
    else
    {
        printf("server shared key is: ");
        _bin_print(g_elink_ctx.keys.shared_key, ret);
    }

    return ret;
}


int _gen_server_dh_pubkey(char *dhp, char *dhg, char *dhkey, unsigned char **key, int len)
{
    DH *server = NULL;
    BIGNUM *clipub = NULL;
    BIO *out = NULL;
    int ret = -1;
    unsigned int plen = 0, glen = 0, klen = 0;
    unsigned char *cdhp = NULL, *cdhg = NULL, *cdhkey = NULL;
    unsigned char key_str[DH_128_KEY_LEN] = {0};

    out = BIO_new(BIO_s_file());

    if (out == NULL)
    {
        ULOG_ERR("bio new failed\n");
        return -1;
    }

    BIO_set_fp(out, stdout, BIO_NOCLOSE);

    server = DH_new();

    if (server == NULL)
    {
        ULOG_ERR("DH new failed\n");
        BIO_free(out);
        return -1;
    }

    plen = _do_b64_cmd((unsigned char *)dhp, strlen(dhp), &cdhp, 0);
    glen = _do_b64_cmd((unsigned char *)dhg, strlen(dhg), &cdhg, 0);
    klen = _do_b64_cmd((unsigned char *)dhkey, strlen(dhkey), &cdhkey, 0);

    if (cdhkey)
        clipub = BN_bin2bn(cdhkey, klen, NULL);
    else
        ULOG_ERR("failed to decode client dhkey\n");

    if (clipub != NULL)
    {
        printf("client public key is: ");
        BN_print(out, clipub);
        printf(" (%u)\n", klen);
    }
    else
    {
        ULOG_ERR("client pub key bin2bn failed\n");
    }

    if (cdhp)
        server->p = BN_bin2bn(cdhp, plen, NULL);
    else
        server->p = NULL;

    if (cdhg)
        server->g = BN_bin2bn(cdhg, glen, NULL);
    else
        server->g = NULL;

    if (server->p && server->g)
        ret = DH_generate_key(server);

    if (ret == 1)
    {
#if ENABLE_DH_DEBUG
        BIO_puts(out, "\nserver p: ");
        BN_print(out, server->p);
        BIO_puts(out, "\nserver g: ");
        BN_print(out, server->g);
        BIO_puts(out, "\nserver private: ");
        BN_print(out, server->priv_key);
        BIO_puts(out, "\nserver public: ");
        BN_print(out, server->pub_key);
        BIO_puts(out, "\n");
#endif

        if (_gen_dh_shared_key(out, clipub, server) < 0)
        {
            ULOG_ERR("failed to generate shared key\n");
            goto done;
        }
    }
    else
    {
        ULOG_ERR("failed to generate dh key\n");
        goto done;
    }

    klen = BN_bn2bin(server->pub_key, key_str);

    ret = _do_b64_cmd(key_str, klen, key, 1);

    if (ret < 0)
        ULOG_ERR("server public key b64 encode failed\n");

done:
    DH_free(server);
    BN_free(clipub);
    BIO_free(out);
    FREE(cdhp);
    FREE(cdhg);
    FREE(cdhkey);
    return ret;
}


int _handle_dh(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int sequence = 0, ret = 0, cnt = 0, len = 0;
    cJSON *jdata = NULL;
    char *mac = NULL;
    unsigned char *pubkey = NULL;
    char *dhkey = NULL, *dhp = NULL, *dhg = NULL;

    ret = _get_string_json_value(obj, "mac", &mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in dh msg\n");
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in dh msg\n");
        goto done;
    }

    jdata = cJSON_GetObjectItem(obj, "data");

    if (cJSON_IsObject(jdata))
    {

        ret = _get_string_json_value(jdata, "dh_p", &dhp);

        if (ret < 0)
            ULOG_ERR("no dh_p in server dh msg\n");

        ret = _get_string_json_value(jdata, "dh_g", &dhg);

        if (ret < 0)
            ULOG_ERR("no dh_g in server dh msg\n");

        ret = _get_string_json_value(jdata, "dh_key", &dhkey);

        if (ret < 0)
            ULOG_ERR("no dh_key in client dh msg\n");

        if (dhp && dhg && dhkey)
        {
            _gen_server_dh_pubkey(dhp, dhg, dhkey, &pubkey, len);
        }
    }

    if (pubkey)
        cnt = asprintf((char **)rsp_buf, "{\"type\":\"dh\",\"sequence\":%d,\"mac\":\"%s\","
                       "\"data\":{\"dh_key\":\"%s\",\"dh_p\":\"%s\",\"dh_g\":\"%s\"}}",
                       sequence, mac, pubkey, dhp, dhg);

done:
    FREE(mac);
    FREE(dhp);
    FREE(dhg);
    FREE(dhkey);
    FREE(pubkey);

    return cnt;
}


int _gen_ecdh_shared_key(const char *clikey, EC_KEY *srv_ecdh)
{
    unsigned char *clipub = NULL;
    int len = -1, de_len = 0;
    EC_POINT *point = NULL;
    const EC_GROUP *group = NULL;

    de_len = _do_b64_cmd((unsigned char *)clikey, strlen(clikey), &clipub, 0);

    if (de_len < 0)
    {
        ULOG_ERR("failed to b64 decode cilent pub key\n");
    }
    else
    {

        printf("client public key is: ");
        _bin_print(clipub, de_len);

        group = EC_KEY_get0_group(srv_ecdh);

        if (group)
            point = EC_POINT_new(group);
        else
            ULOG_ERR("EC_KEY_get0_group failed\n");

        if (point)
            len = EC_POINT_oct2point(group, point, clipub, ECDH_112_KEY_SIZE, NULL);
        else
            ULOG_ERR("EC_POINT_new failed\n");

        if (len)
        {
            g_elink_ctx.keys.shared_key = (unsigned char *)malloc(AES_128_BLOCK_SIZE);
        }
        else
        {
            ULOG_ERR("EC_POINT_oct2point failed\n");
        }

        if (g_elink_ctx.keys.shared_key == NULL)
        {
            ULOG_ERR("Failed to malloc shared key\n");
        }
        else
        {
            memset(g_elink_ctx.keys.shared_key, 0, AES_128_BLOCK_SIZE);
            len = ECDH_compute_key(g_elink_ctx.keys.shared_key, ECDH_112_KEY_LEN, point, srv_ecdh, NULL);

            if (len)
            {
                printf("server shared key is: ");
                _bin_print(g_elink_ctx.keys.shared_key, len);
            }
            else
            {
                ULOG_ERR("ECDH_compute_key failed\n");
            }
        }

        EC_POINT_free(point);
        FREE(clipub);
    }

    return len;
}


int _gen_server_ecdh_pubkey(const char *clikey, unsigned char **outkey)
{
    int len = 0;
    unsigned char pubkey[ECDH_112_KEY_SIZE] = {0};
    EC_POINT *point = NULL;
    const EC_GROUP *group = NULL;
    EC_KEY *srv_ecdh = NULL;

    srv_ecdh = EC_KEY_new_by_curve_name(NID_secp112r1);

    if (srv_ecdh == NULL)
    {
        ULOG_ERR("EC_KEY new failed\n");
        goto done;
    }

    if (!EC_KEY_generate_key(srv_ecdh))
    {
        ULOG_ERR("EC_KEY generate failed\n");
        goto done;
    }

    group = EC_KEY_get0_group(srv_ecdh);
    point = (EC_POINT *)EC_KEY_get0_public_key(srv_ecdh);

    len = EC_POINT_point2oct(group, point, POINT_CONVERSION_COMPRESSED,
                             pubkey, sizeof(pubkey), NULL);
#if ENABLE_DH_DEBUG
    printf("server ecdh pubkey is: ");
    _bin_print(pubkey, len);
#endif

    if (len > 0)
    {

        if (_do_b64_cmd(pubkey, len, outkey, 1) == 0)
            ULOG_ERR("failed to b64 encode server ecdh public key\n");

        len = _gen_ecdh_shared_key(clikey, srv_ecdh);
    }

done:
    EC_KEY_free(srv_ecdh);
    return len;
}


int _handle_ecdh(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int sequence = 0, ret = 0, cnt = 0;
    cJSON *jdata = NULL;
    char *mac = NULL;
    unsigned char *pubkey = NULL;
    char *ecdhkey = NULL;

    ret = _get_string_json_value(obj, "mac", &mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in ecdh msg\n");
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in ecdh msg\n");
        goto done;
    }

    jdata = cJSON_GetObjectItem(obj, "data");

    if (cJSON_IsObject(jdata))
    {

        ret = _get_string_json_value(jdata, "ecdh_key", &ecdhkey);

        if (ret < 0)
            ULOG_ERR("no ecdh_key in client ecdh msg\n");
        else
            _gen_server_ecdh_pubkey(ecdhkey, &pubkey);
    }

    if (pubkey)
        cnt = asprintf((char **)rsp_buf, "{\"type\":\"ecdh\",\"sequence\":%d,\"mac\":\"%s\","
                       "\"data\":{\"ecdh_key\":\"%s\"}}", sequence, mac, pubkey);

done:
    FREE(mac);
    FREE(ecdhkey);
    FREE(pubkey);

    return cnt;
}


int _handle_dev_reg(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int ret = 0, cnt = 0;
    int sequence = 0;
    cJSON *data = NULL;

    ret = _get_string_json_value(obj, "mac", &g_elink_ctx.ap.mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in keyngreq msg\n");
        goto done;
    }

    ret = _convert_mac(g_elink_ctx.ap.mac);

    if (ret < 0)
    {
        ULOG_ERR("convert mac error: %s\n", g_elink_ctx.ap.mac);
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in dev_reg msg\n");
        goto done;
    }

    data = cJSON_GetObjectItem(obj, "data");

    if (!data)
    {
        ULOG_ERR("no data in dev_reg msg\n");
        goto done;
    }
	printf("===============%s [%d]\n", __FUNCTION__, __LINE__);
    _get_string_json_value(data, "vendor", &g_elink_ctx.ap.vendor);
    _get_string_json_value(data, "model", &g_elink_ctx.ap.model);
    _get_string_json_value(data, "swversion", &g_elink_ctx.ap.swver);
    _get_string_json_value(data, "hdversion", &g_elink_ctx.ap.hdver);
    _get_string_json_value(data, "sn", &g_elink_ctx.ap.sn);
    _get_string_json_value(data, "ipaddr", &g_elink_ctx.ap.ipaddr);

    _get_gateway_mac();

    if (IS_EMPTY_STRING(g_elink_ctx.ap.vendor))
    {
        ULOG_ERR("no vendor in dev_reg msg\n");
        goto done;
    }

    if (IS_EMPTY_STRING(g_elink_ctx.ap.model))
    {
        ULOG_ERR("no model in dev_reg msg\n");
        goto done;
    }

    if (IS_EMPTY_STRING(g_elink_ctx.ap.swver))
    {
        ULOG_ERR("no swversion in dev_reg msg\n");
        goto done;
    }

    if (IS_EMPTY_STRING(g_elink_ctx.ap.hdver))
    {
        ULOG_ERR("no hdversion in dev_reg msg\n");
        goto done;
    }

    if (IS_EMPTY_STRING(g_elink_ctx.ap.sn) || strlen(g_elink_ctx.ap.sn) < ELINK_SN_LEN)
    {
        ULOG_WARN("no sn in dev_reg msg, use default sn\n");
        FREE(g_elink_ctx.ap.sn);
        g_elink_ctx.ap.sn = malloc(ELINK_SN_LEN + 1);
        sprintf(g_elink_ctx.ap.sn, "FFFFFFFFFFFFFFFFFFFFFF%s", g_elink_ctx.ap.mac);
    }

    if (IS_EMPTY_STRING(g_elink_ctx.ap.ipaddr))
    {
        ULOG_ERR("no ipaddr in dev_reg msg\n");
        //goto done;
    }

    cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
                   sequence, g_elink_ctx.ap.mac);

done:
    return cnt;
}

int _handle_keepalive(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int ret = 0, cnt = 0;
    char *mac = NULL;
    int sequence = 0;

    ret = _get_string_json_value(obj, "mac", &mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in keepalive msg\n");
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in keepalive msg\n");
        goto done;
    }

    cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
                   sequence, mac);

done:
    FREE(mac);

    return cnt;
}


int _handle_ack(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
	char *jstr = NULL;
	unsigned char *buf = NULL;
	unsigned int buflen = 0;
	unsigned char *b64_msg = NULL;
	unsigned char *en_msg = NULL;
	int ret = 0, sequence = 0;
	int b64_len = 0, en_len = 0;
	char *id = NULL;
	struct spp_info *p = NULL;
	int fun_index = 0;;
	ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

	if (ret < 0)
	{
	    ULOG_ERR("no sequence in ack msg\n");
	    //goto done;
	}

	list_for_each_entry(p, &g_elink_ctx.spp_list, list)
	{
	    if (sequence == p->sequence)
	    {
	        id = p->id;
		 fun_index = p->cur_index;
	        uloop_timeout_cancel(&p->timer);
	        //printf("found id %s, sequence %d\n", p->id, p->sequence);
	        break;
	    }
	}
	
	if(item_array[fun_index].result_check)
	{
		item_array[fun_index].result_check(obj);
	}

	if(strcmp(item_array[fun_index].item_name,EXEC_ROAMING_SET))
	{
		local_test_timer.index = fun_index + 1;
		uloop_timeout_set(&local_test_timer,item_array[fun_index].waittime);
	}
#if 0
    if (!id)
    {
        p = NULL;
        goto done;
    }

    jstr = cJSON_PrintUnformatted(obj);

    b64_len = _do_b64_cmd((unsigned char *)jstr, strlen(jstr), &b64_msg, 1);

    if (b64_len > 0)
    {
        buflen = asprintf((char **)&buf, "{\"Result\":%d,\"Ack\":\"SetPluginParams\",\"return_Parameter\":\"%s\",\"ID\":\"%s\"}",
                          0, b64_msg, id);

        if (buflen > 0)
        {

            ULOG_INFO("(remote) -> %s (%d)\n", buf, buflen);

            if (_do_aes_ecb_crypt(buf, buflen, &en_msg, &en_len, g_elink_ctx.keys.server_key, 1) < 0)
                goto done;

            if (en_len > 0)
            {
                //_send_remote_msg(en_msg, en_len);
            }
            else
            {
                ULOG_ERR("%s: RSA encrypt failed.\n", __func__);
            }

        }
        else
        {
            ULOG_ERR("%s: asprintf failed\n", __func__);
        }
    }

done:
    FREE(b64_msg);
    FREE(buf);
    cJSON_free(jstr);

    if (p)
    {
        list_del(&p->list);
        FREE(p->id);
        FREE(p);
        _dump_list(2);
    }
	#endif

    return 0;
}

int _handle_status(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    return _handle_ack(obj, c, NULL);
}


int _handle_dev_report(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
	int ret = 0, cnt = 0;
	char *mac = NULL;
	int sequence = 0;
	char *resurt_value = NULL;

	ret = _get_string_json_value(obj, "mac", &mac);

	if (ret < 0)
	{
	    ULOG_ERR("no mac in dev_report msg\n");
	    goto done;
	}

	ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

	if (ret < 0)
	{
	    ULOG_ERR("no sequence in dev_report msg\n");
	    goto done;
	}

	cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
	               sequence, mac);

	printf("===============%s [%d]\n", __FUNCTION__, __LINE__);
	if(del_mac_list[0] != 0x0)
	{
		resurt_value = cJSON_Print(obj);
		if(strstr(resurt_value,del_mac_list))
		{
			printf("\n \033[;31m test  deassociation error !!!!!! \033[0m\n");
			FREE(resurt_value);
			uloop_timeout_cancel(&local_dev_report_timer);
			
			goto done;
		}
		
		printf("\n \033[;34m test  deassociation sucess !!!!!! \033[0m\n");
		FREE(resurt_value);
		send_getrssinfo();
		memset(del_mac_list,0x0,16);
		uloop_timeout_cancel(&local_dev_report_timer);
	}

	

	done:
	FREE(mac);

	return cnt;
}


int _handle_roaming_report(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
	int i = 0;
	int ret = 0, cnt = 0;
	char *mac = NULL;
	int sequence = 0;
	int roaming_array_size = 0;
	cJSON *tmp = NULL;
	cJSON *mac_tmp = NULL;
	cJSON *test = NULL;
	cJSON *roaming_array = 0;
	cJSON *roaming_report = NULL;
	char *pppp = NULL;
	ret = _get_string_json_value(obj, "mac", &mac);

	if (ret < 0)
	{
	    ULOG_ERR("no mac in dev_report msg\n");
	    goto done;
	}

	ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

	if (ret < 0)
	{
	    ULOG_ERR("no sequence in dev_report msg\n");
	    goto done;
	}
	
	cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
	               sequence, mac);
	uloop_timeout_cancel(&local_roaming_timer);
	
	roaming_report = cJSON_GetObjectItem(obj,"roaming_report");

	pppp = cJSON_Print(roaming_report);
	printf("=======%s========%s [%d]\n",pppp, __FUNCTION__, __LINE__);
	free(pppp);
	if(roaming_report == NULL)
	{
		printf("\n \033[;31m test  error !!!!!! \033[0m\n");
		goto done;
	}

	roaming_array_size = cJSON_GetArraySize(roaming_report);

	if(roaming_array_size == 0)
	{
		
		//printf("\n \033[;31m test  roaming_array_size error !!!!!! \033[0m\n");
		goto done;
	
	}
		
	for(i = 0;i<roaming_array_size;i++)
	{
		tmp = cJSON_GetArrayItem(roaming_report,i);
		mac_tmp = cJSON_GetObjectItem(tmp,"mac");
		strcpy(mac_list,mac_tmp->valuestring);
		uloop_timeout_set(&local_deassociation_timer,ELINKCC_5S_INTERVAL);
		
	}
	
	printf("\n \033[;34m test  roaming_array_size suecss !!!!!! \033[0m\n");
	
	done:
	FREE(mac);

    return cnt;
}

int _handle_rssiinfo_report(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
	int i = 0;
	int ret = 0, cnt = 0;
	char *mac = NULL;
	int sequence = 0;
	int roaming_array_size = 0;
	cJSON *tmp = NULL;
	cJSON *mac_tmp = NULL;
	cJSON *test = NULL;
	cJSON *roaming_array = 0;
	cJSON *roaming_report = NULL;
	char *pppp = NULL;
	ret = _get_string_json_value(obj, "mac", &mac);

	if (ret < 0)
	{
	    ULOG_ERR("no mac in dev_report msg\n");
	    goto done;
	}

	ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

	if (ret < 0)
	{
	    ULOG_ERR("no sequence in dev_report msg\n");
	    goto done;
	}
	
	cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
	               sequence, mac);

	uloop_timeout_cancel(&local_getrssinfo_timer);
	
	roaming_report = cJSON_GetObjectItem(obj,"rssiinfo");

	pppp = cJSON_Print(roaming_report);
	printf("\n \033[;34m test  rssiinfo suecss !!!!!! \033[0m\n");
	free(pppp);
	
	done:
	FREE(mac);

    return cnt;
}


int _handle_wan_report(cJSON *obj, struct cmd_info *c, unsigned char **rsp_buf)
{
    int ret = 0, cnt = 0;
    char *mac = NULL, *ipaddr = NULL, *status = NULL;
    cJSON *jsts = NULL;
    int sequence = 0;

    ret = _get_string_json_value(obj, "mac", &mac);

    if (ret < 0)
    {
        ULOG_ERR("no mac in wan_report msg\n");
        goto done;
    }

    ret = _get_int_json_value(obj, "sequence", cJSON_Number, &sequence);

    if (ret < 0)
    {
        ULOG_ERR("no sequence in wan_report msg\n");
        goto done;
    }

    jsts = cJSON_GetObjectItem(obj, "status");

    if (jsts)
    {
        _get_string_json_value(jsts, "status", &status);

        if (IS_EMPTY_STRING(status))
        {
            ULOG_ERR("invalid status in wan_report msg\n");
            goto done;
        }
        else if (_strcmp(status, "up") == 0)
        {

            _get_string_json_value(jsts, "ipaddr", &ipaddr);

            if (!IS_EMPTY_STRING(ipaddr) && _strcmp(ipaddr, g_elink_ctx.ap.ipaddr) != 0)
            {
                FREE(g_elink_ctx.ap.ipaddr);
                g_elink_ctx.ap.ipaddr = strdup(ipaddr);
            }

            FREE(ipaddr);

            if (g_elink_ctx.remote.fd.fd <= 0)
                uloop_timeout_set(&remote_connect_timer, ELINKCC_200MS_INTERVAL);

        }
        else if (_strcmp(status, "down") == 0)
        {
            if (g_elink_ctx.remote.fd.fd > 0)
                uloop_timeout_set(&remote_disconnect_timer, 0);
        }
        else if (_strcmp(status, "ip_changed") == 0)
        {

            uloop_timeout_set(&remote_disconnect_timer, 0);

            FREE(g_elink_ctx.ap.ipaddr);
            _get_string_json_value(jsts, "ipaddr", &g_elink_ctx.ap.ipaddr);

            uloop_timeout_set(&remote_connect_timer, ELINKCC_200MS_INTERVAL);

        }
        else
        {
            ULOG_ERR("unknown status: %s\n", status);
        }

        FREE(status);
    }

    cnt = asprintf((char **)rsp_buf, "{\"type\":\"ack\",\"sequence\":%d,\"mac\":\"%s\"}",
                   sequence, mac);

done:
    FREE(mac);

    return cnt;
}


int _add_remote_msg_to_list(char *msg, int len)
{
    struct req_info *request = NULL;

    /* freed in _process_local_msg */
    request = malloc(sizeof(struct req_info));

    if (request)
    {
        request->len = len;
        request->raw = malloc(len + 1);

        if (request->raw)
        {
            memcpy(request->raw, msg, len);
            request->raw[len] = '\0';
            list_add_tail(&request->list, &g_elink_ctx.req_list);
            _dump_list(0);
            uloop_timeout_set(&remote_action_timer, ELINKCC_100MS_INTERVAL);
            return 1;
        }
        else
        {
            ULOG_ERR("failed to malloc req_list new item.raw\n");
        }
    }
    else
    {
        ULOG_ERR("failed to malloc req_list new item\n");
    }

    return 0;
}


int _add_local_msg_to_list(char *msg, int len)
{
    struct cmd_info *cmd = NULL;

    /* freed in _process_remote_msg */
    cmd = malloc(sizeof(struct cmd_info));

    if (cmd)
    {
        cmd->len = len;
        cmd->content = malloc(len + 1);

        if (cmd->content)
        {
            memcpy(cmd->content, msg, len);
            cmd->content[len] = '\0';
            list_add_tail(&cmd->list, &g_elink_ctx.cmd_list);
            _dump_list(1);
            uloop_timeout_set(&local_action_timer, ELINKCC_100MS_INTERVAL);
            return 1;
        }
        else
        {
            ULOG_ERR("failed to malloc cmd_list new item.content\n");
        }
    }
    else
    {
        ULOG_ERR("failed to malloc cmd_list new item\n");
    }

    return 0;
}

static void _elink_internal_read(struct ustream *s, int bytes, int header_len, int tail_len, tail_check tc, add_to_list cb)
{
    char *buf = NULL, *ptr = NULL;
    int slen = 0, len = 0, offset = 0, onemsg = 0;
    static unsigned short copy_len = 0, left_len = 0, partial_len = 0;

    do
    {
        buf = ustream_get_read_buf(s, &slen);
        ptr = buf;

        //printf("--------%d buffer header len %d (%d/%d)-------\n", s->r.buffer_len, header_len, bytes, slen);
        //_bin_print((unsigned char *)ptr, slen);

        if (!g_elink_ctx.msg)
        {
        again:

            if (slen < header_len)
            {
                ULOG_ERR("invalid request, len %d\n", slen);
                goto done;
            }

            len = _check_msg_header(ptr, header_len);

            if (len == 0 || (len > 16384))
            {
                ULOG_ERR("invalid msg header, len = %d\n", len);
                goto done;
            }

            if ((header_len + len) == slen)
            {
                //one and only msg
                onemsg = 1;

                if ((tc && !tc(ptr + header_len + len - tail_len)) || (cb && !cb(ptr + header_len, len)))
                    goto done;

            }
            else if (len < slen)
            {
                //multiple msgs
                while (ptr - buf <= slen)
                {
                    if (ptr - buf + header_len + len > slen)
                        break;

                    if ((tc && !tc(ptr + header_len + len - tail_len)) || (cb && !cb(ptr + header_len, len)))
                        goto done;

                    ptr += (len + header_len);

                    offset = ptr - buf;

                    if (offset == slen)
                    {
                        onemsg = 1;
                        break;
                    }

                    if (slen - offset >= header_len)
                    {

                        len = _check_msg_header(ptr, header_len);

                        if (len > 0 && (offset + len > slen))
                        {
                            break;
                        }
                    }
                    else if (slen > offset)
                    {
                        //msg header is not complete
                        g_elink_ctx.msg = malloc(header_len + 1);

                        if (g_elink_ctx.msg)
                            memcpy(g_elink_ctx.msg, ptr, slen - offset);

                        partial_len = slen - offset;
                        break;
                    }
                } //while
            } //if

            if (!onemsg && !partial_len && len > 0)
            {
                //msg is not complete

                copy_len = slen - (ptr - buf + header_len);
                left_len = len - copy_len;
                g_elink_ctx.msg = malloc(len + 1);

                if (g_elink_ctx.msg && copy_len)
                    memcpy(g_elink_ctx.msg, ptr + header_len, copy_len);
            }
        }
        else if (g_elink_ctx.msg)
        {
            if (left_len > 0)
            {

                //add remaining msg
                if (left_len <= slen)
                {
                    memcpy(g_elink_ctx.msg + copy_len, buf, left_len);
                    g_elink_ctx.msg[copy_len + left_len] = '\0';

                    if ((tc && !tc(buf + left_len - tail_len)) || (cb && !cb(g_elink_ctx.msg, copy_len + left_len)))
                    {
                        FREE(g_elink_ctx.msg);
                        goto done;
                    }

                    FREE(g_elink_ctx.msg);
                    ptr = buf + left_len;
                    left_len = 0;
                }
                else
                {

                    memcpy(g_elink_ctx.msg + copy_len, buf, slen);
                    copy_len += slen;
                    left_len -= slen;
                    ptr = buf + slen;
                }

            }
            else if (partial_len)
            {
                //add remaining head + msg
                memcpy(g_elink_ctx.msg + partial_len, buf, header_len - partial_len);

                len = _check_msg_header(g_elink_ctx.msg, header_len);
                FREE(g_elink_ctx.msg);

                if (len)
                {

                    offset = header_len - partial_len;

                    if ((tc && !tc(buf + offset + len - tail_len)) || (cb && !cb(buf + offset, len)))
                    {
                        partial_len = 0;
                        goto done;
                    }

                    partial_len = 0;
                    ptr = buf + offset + len;
                }
            }

            if (ptr - buf < slen)
                goto again;
        }

    done:
        ustream_consume(s, slen);
        bytes -= slen;
    }
    while (bytes > 0);
}


static void elink_remote_read_cb(struct ustream *s, int bytes)
{
    _elink_internal_read(s, bytes, ELINKCC_HEADER_LEN, ELINKCC_TAIL_LEN, _check_msg_tail, _add_remote_msg_to_list);
}


int _send_local_msg(unsigned char *msg, int msg_len, int isdh)
{
    unsigned char *outbuf = NULL, *hdrbuf = NULL;
    unsigned char *pad_msg = NULL;
    int outlen = 0, ret = 0, pad_len = 0;

    if (g_elink_ctx.keys.shared_key && (isdh == 0))
    {

        if (msg_len % AES_128_BLOCK_SIZE)
        {
            pad_len = msg_len + AES_128_BLOCK_SIZE - (msg_len % AES_128_BLOCK_SIZE);
            pad_msg = calloc(1, pad_len); //memwatch realloc will not work

            if (!pad_msg)
            {
                ULOG_ERR("failed to malloc pad_msg (%d)\n", pad_len);
                return 0;
            }
            else
            {
                memcpy(pad_msg, msg, msg_len);
            }

            _do_aes_cbc_crypt(pad_msg, pad_len, &outbuf, &outlen, g_elink_ctx.keys.shared_key, 1);
        }
        else
        {
            _do_aes_cbc_crypt(msg, msg_len, &outbuf, &outlen, g_elink_ctx.keys.shared_key, 1);
        }

        //_bin_print(outbuf, (unsigned int)outlen);
        FREE(pad_msg);

        if (outlen > 0)
        {
            hdrbuf = _add_elink_hdr_local(outbuf, (unsigned int)outlen);
            FREE(outbuf);

            if (hdrbuf)
            {
                ret = ustream_write(&g_elink_ctx.local.stream, (char *)hdrbuf, outlen + ELINK_HEADER_LEN, 0);
                FREE(hdrbuf);
            }
        }
    }
    else
    {
        hdrbuf = _add_elink_hdr_local(msg, msg_len);

        if (hdrbuf)
        {
            ret = ustream_write(&g_elink_ctx.local.stream, (char *)hdrbuf, msg_len + ELINK_HEADER_LEN, 0);
            FREE(hdrbuf);
        }
    }

    return ret;
}

int _send_remote_msg(unsigned char *msg, int len)
{
    char *hdrbuf = NULL;
    unsigned char *b64_msg = NULL;
    int b64_len = 0;
    int ret = 0;

    b64_len = _do_b64_cmd(msg, len, &b64_msg, 1);
    FREE(msg);

    if (b64_len == -1)
    {
        ULOG_ERR("b64 encode failed.\n");
        return -1;
    }

    hdrbuf = (char *)_add_elink_hdr_remote(b64_msg, b64_len);
    FREE(b64_msg);

    if (!hdrbuf)
    {
        ULOG_ERR("add hdr failed.\n");
        return -1;
    }

    ret = ustream_write(&g_elink_ctx.remote.stream, hdrbuf, ELINK_MSG_LEN(b64_len), 0);

    FREE(hdrbuf);

    return ret;
}

int _is_same_server(void)
{
    if (IS_EMPTY_STRING(g_elink_ctx.server.addr) ||
            IS_EMPTY_STRING(g_elink_ctx.server.bssaddr))
        return 1;

    if (_strcmp(g_elink_ctx.server.addr, g_elink_ctx.server.bssaddr) ||
            (g_elink_ctx.server.port != g_elink_ctx.server.bssport))
    {
        return 0;
    }

    return 1;
}



int _is_ack_type(enum elink_msg_type type)
{
    return (type == EMT_ACK || type == EMT_STATUS);
}



void _reconnect_server(int interval)
{
    ULOG_DEBUG("reconnect server\n");
    uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
    uloop_timeout_set(&remote_connect_timer, ELINKCC_200MS_INTERVAL + interval);
}

int _parse_boot_resp(cJSON *obj)
{
    cJSON *bizplat = NULL, *item = NULL;
    char *serverip = NULL, *backup = NULL;
    int result = 1, serverport = 0, backport = 0, i = 0, j = 0, chg = 0;
    unsigned char *msg = NULL;
    int msg_len = 0;

    _get_int_json_value(obj, "Result", cJSON_Number, &result);

    if (0 == result)
    {

        g_elink_ctx.is_bss = 0;
        bizplat = cJSON_GetObjectItem(obj, "BizPlat");

        if (!bizplat)
        {
            ULOG_ERR("failed to get BizPlat\n");
            return -1;
        }

        if (cJSON_IsArray(bizplat))
        {

            json_array_foreach(bizplat, i, item)
            {
                if (i == 0)
                {

                    _get_string_json_value(item, "ServerAddr", &serverip);
                    _get_int_json_value(item, "ServerPort", cJSON_Number, &serverport);

                    if (!IS_EMPTY_STRING(serverip) && IS_VALID_PORT(serverport))
                    {
                        _set_key_value("ServerAddr", cJSON_String, serverip, 0);
                        _set_key_value("ServerPort", cJSON_Number, NULL, serverport);
                    }

                    if (!IS_EMPTY_STRING(serverip) &&
                            (!g_elink_ctx.server.addr || (_strcmp(g_elink_ctx.server.addr, serverip) != 0)))
                    {
                        FREE(g_elink_ctx.server.addr);
                        g_elink_ctx.server.addr = strdup(serverip);
                        chg = 1;
                    }

                    if (IS_VALID_PORT(serverport) && g_elink_ctx.server.port != serverport)
                    {
                        g_elink_ctx.server.port = serverport;
                        chg = 1;
                    }

                    FREE(serverip);
                }
                else
                {

                    _get_string_json_value(item, "ServerAddr", &backup);
                    _get_int_json_value(item, "ServerPort", cJSON_Number, &backport);

                    if (!IS_EMPTY_STRING(backup) && IS_VALID_PORT(backport))
                    {
                        _set_backup_servers(backup, backport, j);

                        FREE(g_elink_ctx.server.backup[j].addr);
                        g_elink_ctx.server.backup[j].addr = strdup(backup);
                        g_elink_ctx.server.backup[j].port = backport;
                        g_elink_ctx.server.backup[j].used = 0;
                        j++;
                    }

                    FREE(backup);
                }
            }

            /* save to flash */
            msg_len = asprintf((char **)&msg, "{\"type\":\"cfg\",\"mac\":\"%s\",\"sequence\":%d,"
                               "\"set\":{\"ctrlcommand\":\"save\"}}", g_elink_ctx.ap.mac, ++g_elink_ctx.sequence);

            if (msg_len > 0)
            {
                ULOG_DEBUG("(local) -> %s (%d)\n", msg, msg_len);
                _send_local_msg(msg, msg_len, 0);
            }

        }
        else
        {
            ULOG_ERR("invalid BizPlat in Boot Ack\n");
        }
    }

    if (-2 == result)
    {
        uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
        ULOG_DEBUG("reconnect the server after 150 minutes\n");
        uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
    }
    else if (0 == result)
    {
        if ((0 == chg) && (!g_elink_ctx.is_bootstrap))
        {
            uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
            ULOG_DEBUG("reconnect ability server after 150 minutes\n");

            /* connect ability server after timeout */
            g_elink_ctx.curr_srv = NULL; //_get_server_addr();

            uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
        }
        else if (g_elink_ctx.server.addr && !_is_same_server())
        {
            g_elink_ctx.is_bootstrap = 0;
            g_elink_ctx.curr_srv = NULL;
            _reconnect_server(0);
        }
        else if (_is_same_server())
        {
            g_elink_ctx.is_bootstrap = 0;
            ULOG_DEBUG("is same server\n");
        }
    }
    else
    {
        _reconnect_server(ELINKCC_30S_INTERVAL);
    }

    FREE(msg);

    return result;
}


int _parse_challenge_resp(cJSON *obj)
{
    int result = 1;

    _get_int_json_value(obj, "Result", cJSON_Number, &result);

    //0, -1, -5
    if (0 == result)
    {
        FREE(g_elink_ctx.keys.challenge_code);
        _get_string_json_value(obj, "ChallengeCode", &g_elink_ctx.keys.challenge_code);
    }
    else
    {
        _reconnect_server(ELINKCC_30S_INTERVAL);
    }

    return result;

}


int _parse_activate_resp(cJSON *obj)
{
    int result = 1;
    unsigned char *msg = NULL;
    int msg_len = 0;

    _get_int_json_value(obj, "Result", cJSON_Number, &result);

    if (0 == result)
    {
        FREE(g_elink_ctx.dev.token);
        _get_string_json_value(obj, "DevToken", &g_elink_ctx.dev.token);
        _set_key_value("DevToken", cJSON_String, g_elink_ctx.dev.token, 0);

        FREE(g_elink_ctx.dev.id);
        _get_string_json_value(obj, "DevID", &g_elink_ctx.dev.id);
        _set_key_value("DevID", cJSON_String, g_elink_ctx.dev.id, 0);

        if (IS_EMPTY_STRING(g_elink_ctx.dev.id) || IS_EMPTY_STRING(g_elink_ctx.dev.token))
        {

            _reconnect_server(ELINKCC_30S_INTERVAL);
            return 1;

        }
        else
        {
            /* save to flash */
            msg_len = asprintf((char **)&msg, "{\"type\":\"cfg\",\"mac\":\"%s\",\"sequence\":%d,"
                               "\"set\":{\"ctrlcommand\":\"save\"}}", g_elink_ctx.ap.mac, ++g_elink_ctx.sequence);

            if (msg_len > 0)
            {
                ULOG_DEBUG("(local) -> %s (%d)\n", msg, msg_len);
                _send_local_msg(msg, msg_len, 0);
            }
        }

    }
    else if (-2 == result)
    {
        uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
        ULOG_DEBUG("reconnect the server after 150 minutes\n");
        uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
    }
    else
    {
        _reconnect_server(ELINKCC_30S_INTERVAL);
    }

    /* send GetChallengeCode again before Connect */
    FREE(g_elink_ctx.keys.challenge_code);

    FREE(msg);

    return result;
}

int _parse_connect_resp(cJSON *obj)
{
    int result = 1, cnt = 0;

    _get_int_json_value(obj, "Result", cJSON_Number, &result);

    FREE(g_elink_ctx.keys.server_key);

    if (0 == result)
    {
        cnt = _get_string_json_value(obj, "SKey", (char **)&g_elink_ctx.keys.server_key);

        if (cnt != CKEY_SKEY_LEN)
        {
            _reconnect_server(ELINKCC_30S_INTERVAL);
        }
    }
    else if (-2 == result)
    {
        FREE(g_elink_ctx.dev.token);
        FREE(g_elink_ctx.dev.id);

        /* send Activate */
        _notify_ap_server(&g_elink_ctx.remote.stream, 0);
    }
    else if (-3 == result)
    {
        uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
        ULOG_DEBUG("reconnect the server after 150 minutes\n");
        uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
    }
    else
    {
        _reconnect_server(ELINKCC_30S_INTERVAL);
    }

    return result;
}

int _parse_heartbeat_resp(cJSON *obj)
{
    int result = -1;

    uloop_timeout_cancel(&remote_ack_timer);

    _get_int_json_value(obj, "Result", cJSON_Number, &result);

    if (0 != result)
        uloop_timeout_set(&remote_ack_timer, ELINKCC_100MS_INTERVAL);

    return result;
}

int _parse_request_connect_bss(cJSON *obj)
{
    char *server = NULL, *port = NULL, *id = NULL;
    char *outbuf = NULL;
    unsigned char *en_msg = NULL;
    int en_len = 0, outlen = 0, ret = 0, pval = 0;

    if (_get_string_json_value(obj, "ID", &id) <= 0)
    {
        ULOG_ERR("%d: invalid ID: %s\n", __LINE__, id);
        goto done;
    }

    if (_get_string_json_value(obj, "Server", &server) < 0)
    {
        ULOG_ERR("%d: invalid Server: %s\n", __LINE__, server);
        goto done;
    }

    if (_get_string_json_value(obj, "Port", &port) < 0)
    {
        ULOG_ERR("%d: invalid Port: %s\n", __LINE__, port);
        goto done;
    }

    pval = atoi(port);

    outlen = asprintf(&outbuf, "{\"Result\":0,\"Ack\":\"RequestConnectBSS\",\"ID\":\"%s\"}", id);

    if (outlen > 0)
    {
        ULOG_INFO("(remote) -> %s (%d)\n", outbuf, outlen);

        if (_do_aes_ecb_crypt((unsigned char *)outbuf, outlen, &en_msg, &en_len, (unsigned char *)g_elink_ctx.keys.server_key, 1) < 0)
            goto done;

        FREE(outbuf);
        _send_remote_msg(en_msg, en_len);
    }
    else
    {
        ULOG_ERR("%d: failed to generate msg\n", __LINE__);
    }

    if (IS_VALID_PORT(pval) && !IS_EMPTY_STRING(server))
    {
        _set_key_value("BSSAddr", cJSON_String, server, 0);
        _set_key_value("BSSPort", cJSON_Number, NULL, pval);

        FREE(g_elink_ctx.server.bssaddr);
        g_elink_ctx.server.bssaddr = server;
        g_elink_ctx.server.bssport = pval;
    }
    else
    {
        FREE(server);
    }

    g_elink_ctx.curr_srv = NULL;
    g_elink_ctx.is_bss = 1;
    uloop_timeout_set(&remote_ack_timer, ELINKCC_30S_INTERVAL);
    uloop_timeout_cancel(&heartbeat_timer);

done:
    FREE(id);
    FREE(port);

    return ret;
}

int _add_mac_and_sequence(char *old, char **new)
{
    cJSON *root = NULL;
    cJSON *item = NULL;

    root = cJSON_Parse(old);

    if (root == NULL)
        return 0;

    item = cJSON_GetObjectItem(root, "mac");

    if (!item)
        cJSON_AddItemToObject(root, "mac", cJSON_CreateString(g_elink_ctx.ap.mac));

    item = cJSON_GetObjectItem(root, "sequence");

    if (!item)
    {
        cJSON_AddItemToObject(root, "sequence", cJSON_CreateNumber(++g_elink_ctx.sequence));
    }
    else
    {
        cJSON_SetNumberValue(item, ++g_elink_ctx.sequence);
    }

    *new = cJSON_PrintUnformatted(root);

    cJSON_Delete(root);

    if (*new == NULL)
        return 0;

    //ULOG_DEBUG("%s: %s\n", __func__, *new);
    return strlen(*new);
}

int _parse_set_plugin_params(cJSON *obj)
{
    char *name = NULL, *id = NULL, *version = NULL;
    char *param_b64 = NULL;
    unsigned char *param_json = NULL;
    char *new_json = NULL;
    int b64_len = 0, json_len = 0;
    struct spp_info *si = NULL;

    /*
    {"RPCMethod":"SetPluginParams","ID":"0huJJ","Plugin_Name":"eLinkAP","Version":"1.0.0",
    "Parameter":"eyJ0eXBlIjoiY2ZnIiwic2VxdWVuY2UiOjAsIm1hYyI6IkY0RTRBRDAwMDVBMSIsInN0Y
    XR1cyI6eyJ3aWZpIjpbeyJyYWRpbyI6eyJtb2RlIjoiMi40RyIsImNoYW5uZWwiOjB9fSx7InJhZGlvIjp
    7Im1vZGUiOiI1RyIsImNoYW5uZWwiOjB9fV19LCJzZXQiOnsid2lmaSI6W3sicmFkaW8iOnsibW9kZSI6I
    jIuNEciLCJjaGFubmVsIjowfSwiYXAiOlt7ImFwaWR4IjowLCJzc2lkIjoiQ2hpbmFOZXQtN0gyTCIsImt
    leSI6IjEyMzQ1Njc4IiwiYXV0aCI6IndwYXBza3dwYTJwc2siLCJlbmNyeXB0IjoiYWVzIn1dfSx7InJhZ
    GlvIjp7Im1vZGUiOiI1RyIsImNoYW5uZWwiOjB9LCIgYXAiOlt7ImFwaWR4IjowLCJzc2lkIjoiQ2hpbmF
    OZXQtN0gyTF81RyIsImtleSI6IjEyMzQ1Njc4IiwiYXV0aCI6IndwYXBza3dwYTJwc2siLCJlbmNyeXB0I
    joiYWVzIn1dfV19fQo="}
    */

    if (_get_string_json_value(obj, "Plugin_Name", &name) <= 0 ||
            _strcmp(name, ELINK_PLUGIN_NAME) != 0)
    {
        ULOG_ERR("%d: invalid Plugin_Name: %s\n", __LINE__, name);
        goto done;
    }

    if (_get_string_json_value(obj, "ID", &id) <= 0)
    {
        ULOG_ERR("%d: invalid ID: %s\n", __LINE__, id);
        goto done;
    }

    if (_get_string_json_value(obj, "Version", &version) <= 0)
    {
        ULOG_ERR("%d: invalid Version: %s\n", __LINE__, version);
        goto done;
    }

    b64_len = _get_string_json_value(obj, "Parameter", &param_b64);

    if (!param_b64)
    {
        ULOG_ERR("%d: failed to get Parameter\n", __LINE__);
        goto done;
    }

    json_len = _do_b64_cmd((unsigned char *)param_b64, b64_len, &param_json, 0);

    if (json_len < 0)
    {
        ULOG_ERR("%d: failed to decode Parameter\n", __LINE__);
        goto done;
    }

    json_len = _add_mac_and_sequence((char *)param_json, &new_json);

    if (json_len <= 0)
    {
        ULOG_ERR("%d: Parameter is null\n", __LINE__);
        goto done;
    }

    /* setup ID/sequence mapping */
    /* freed in _handler_ack and _spp_ack_tmot_cb */
    si = calloc(1, sizeof(struct spp_info));

    if (si)
    {
        si->sequence = g_elink_ctx.sequence;
        si->id = strdup(id);
        si->timer.cb = _spp_ack_tmot_cb;
        list_add_tail(&si->list, &g_elink_ctx.spp_list);
        _dump_list(2);
        ULOG_DEBUG("link id %s and sequence %d\n", si->id, si->sequence);
    }
    else
    {
        ULOG_ERR("%d: failed to malloc spp_info\n", __LINE__);
        goto done;
    }

    ULOG_DEBUG("(local) -> %s (%d)\n", new_json, json_len);
    _send_local_msg((unsigned char *)new_json, json_len, 0);
    uloop_timeout_set(&si->timer, ELINKCC_100S_INTERVAL);

done:
    FREE(id);
    FREE(version);
    FREE(name);
    FREE(param_b64);
    FREE(param_json);
    cJSON_free(new_json);

    return 0;
}


int _parse_list_plugin(cJSON *obj, char *method)
{
    char *id = NULL;
    unsigned char *outbuf = NULL, *en_msg = NULL;
    int len = 0, en_len = 0;

    /*
    {"RPCMethod":"ListPlugin","ID":"83c322fa-ada0-11e7-a9d4-f80f41f70c5a"}
    */

    if (_get_string_json_value(obj, "ID", &id) <= 0)
    {
        ULOG_ERR("%d: invalid ID: %s\n", __LINE__, id);
        goto done;
    }

    len = asprintf((char **)&outbuf, "{\"Result\":0,\"ID\":\"%s\",\"Ack\":\"%s\","
                   "\"Plugin\":[{\"Plugin_Name\":\"%s\",\"Version\":\"%s\",\"Run\":1}]}",
                   id, method, ELINK_PLUGIN_NAME, g_elink_ctx.ap.swver);

    if (len > 0)
    {
        ULOG_INFO("(remote) -> %s (%d)\n", outbuf, len);

        if (_do_aes_ecb_crypt(outbuf, len, &en_msg, &en_len, g_elink_ctx.keys.server_key, 1) < 0)
            goto done;

        _send_remote_msg(en_msg, en_len);
    }
    else
    {
        ULOG_ERR("%d: failed to generate msg\n", __LINE__);
    }

done:
    FREE(id);
    FREE(outbuf);

    return 0;
}

int _parse_unsupported_method(cJSON *obj, char *method)
{
    char *id = NULL;
    unsigned char *outbuf = NULL, *en_msg = NULL;
    int len = 0, en_len = 0;

    /*
    {"RPCMethod":"XXXX","ID":"83c322fa-ada0-11e7-a9d4-f80f41f70c5a"}
    */

    if (_get_string_json_value(obj, "ID", &id) <= 0)
    {
        ULOG_ERR("%d: invalid ID: %s\n", __LINE__, id);
        goto done;
    }

    len = asprintf((char **)&outbuf, "{\"Result\":-4,\"ID\":\"%s\",\"Ack\":\"%s\"}", id, method);

    if (len > 0)
    {
        ULOG_INFO("(remote) -> %s (%d)\n", outbuf, len);

        if (_do_aes_ecb_crypt(outbuf, len, &en_msg, &en_len, g_elink_ctx.keys.server_key, 1) < 0)
            goto done;

        _send_remote_msg(en_msg, en_len);
    }
    else
    {
        ULOG_ERR("%d: failed to generate msg\n", __LINE__);
    }

done:
    FREE(id);
    FREE(outbuf);

    return 0;
}


void _update_ckey(void)
{
    FREE(g_elink_ctx.keys.client_key);
    g_elink_ctx.keys.client_key = _get_random_string(CKEY_SKEY_LEN);
}


void _get_ap_ipaddr(void)
{
    socklen_t len = sizeof(struct sockaddr);
    struct sockaddr laddr;
    char localaddr[INET_ADDRSTRLEN] = {0};

    if (getsockname(g_elink_ctx.remote.fd.fd, &laddr, &len) == 0)
    {
        struct sockaddr_in *sin = (struct sockaddr_in *)(&laddr);

        inet_ntop(AF_INET, &(sin->sin_addr), localaddr, INET_ADDRSTRLEN);
        g_elink_ctx.ap.ipaddr = strdup(localaddr);
    }
}


int _gen_boot_msg(unsigned char **buf)
{
    char *result = NULL;
    int cnt = 0;

    _update_ckey();

    cnt = asprintf(&result, "{\"RPCMethod\":\"Boot\",\"DevType\":\"%s\",\"Vendor\":\"%s\","
                   "\"Model\":\"%s\",\"MAC\":\"%s\",\"FirmwareVer\":\"%s\",\"HardwareVer\":\"%s\","
                   "\"bootstrap\":\"%d\",\"CKey\":\"%s\"}",
                   "E-Link AP", g_elink_ctx.ap.vendor, g_elink_ctx.ap.model, g_elink_ctx.ap.mac,
                   g_elink_ctx.ap.swver, g_elink_ctx.ap.hdver, g_elink_ctx.is_bootstrap, g_elink_ctx.keys.client_key);

    *buf = (unsigned char *)result;

    return cnt;
}

int _gen_activate_msg(unsigned char **buf)
{
    char *result = NULL;
    int cnt = 0;

    if (IS_EMPTY_STRING(g_elink_ctx.keys.challenge_code))
    {
        cnt = asprintf(&result, "{\"RPCMethod\":\"GetChallengeCode\",\"MAC\":\"%s\"}", g_elink_ctx.ap.mac);
        *buf = (unsigned char *)result;
        return cnt;
    }

    _update_ckey();

    if (IS_EMPTY_STRING(g_elink_ctx.ap.ipaddr))
        _get_ap_ipaddr();

    cnt = asprintf(&result, "{\"RPCMethod\":\"Activate\",\"CKey\":\"%s\",\"Vendor\":\"%s\","
                   "\"Model\":\"%s\",\"FirmwareVer\":\"%s\",\"HardwareVer\":\"%s\","
                   "\"MAC\":\"%s\",\"IPAddr\":\"%s\",\"SN\":\"%s\",\"ChallengeCode\":\"%s\",\"LOID\":\"%s\","
                   "\"PlatformID\":\"%s\",\"CloudClientVer\":\"%s\",\"MiddleWareVer\":\"%s\",\"MiddleWareBakVer\":\"%s\"}",
                   g_elink_ctx.keys.client_key, g_elink_ctx.ap.vendor, g_elink_ctx.ap.model,
                   g_elink_ctx.ap.swver, g_elink_ctx.ap.hdver, g_elink_ctx.ap.mac, g_elink_ctx.ap.ipaddr,
                   g_elink_ctx.ap.sn, g_elink_ctx.keys.challenge_code, "", "", ELINK_VERSION, "", "");

    *buf = (unsigned char *)result;

    return cnt;
}

int _gen_connect_msg(unsigned char **buf, char *token, char *id)
{
    char *result = NULL;
    int cnt = 0;

    if (!token || !id)
        return -1;

    if (IS_EMPTY_STRING(g_elink_ctx.keys.challenge_code))
    {
        cnt = asprintf(&result, "{\"RPCMethod\":\"GetChallengeCode\",\"MAC\":\"%s\"}", g_elink_ctx.ap.mac);
        *buf = (unsigned char *)result;
        return cnt;
    }

    _update_ckey();

    if (IS_EMPTY_STRING(g_elink_ctx.ap.ipaddr))
        _get_ap_ipaddr();

    //TODO: Flag and upgrade_ID
    cnt = asprintf(&result, "{\"RPCMethod\":\"Connect\",\"DevToken\":\"%s\",\"DevID\":\"%s\","
                   "\"CKey\":\"%s\",\"Flag\":\"%d\",\"Vendor\":\"%s\",\"Model\":\"%s\","
                   "\"HardwareVer\":\"%s\",\"FirmwareVer\":\"%s\",\"MAC\":\"%s\",\"IPAddr\":\"%s\","
                   "\"CloudClientVer\":\"%s\",\"MiddleWareVer\":\"%s\",\"MiddleWareBakVer\":\"%s\","
                   "\"upgrade_ID\":\"%s\",\"LOID\":\"%s\",\"PlatformID\":\"%s\",\"UPPER_MAC\":\"%s\",\"ChallengeCode\":\"%s\"}",
                   token, id, g_elink_ctx.keys.client_key, 0,
                   g_elink_ctx.ap.vendor, g_elink_ctx.ap.model,
                   g_elink_ctx.ap.hdver, g_elink_ctx.ap.swver,
                   g_elink_ctx.ap.mac, g_elink_ctx.ap.ipaddr, ELINK_VERSION, "", "", "", "", "",
                   g_elink_ctx.ap.gwmac, g_elink_ctx.keys.challenge_code);

    *buf = (unsigned char *)result;

    return cnt;
}

int _gen_heartbeat_msg(unsigned char **buf)
{
    char *result = NULL;
    int cnt = 0;

    cnt = asprintf(&result, "{\"RPCMethod\":\"Heartbeat\",\"MAC\":\"%s\",\"IPAddr\":\"%s\"}",
                   g_elink_ctx.ap.mac, g_elink_ctx.ap.ipaddr);

    *buf = (unsigned char *)result;
    return cnt;
}


int _notify_ap_server(struct ustream *s, int ishb)
{
    unsigned char *msg = NULL;
    unsigned char *en_msg = NULL;
    int len = 0, en_len = 0;
    cJSON *obj = NULL;

    if (!ishb)
    {
        if (g_elink_ctx.is_bss)
            len = _gen_boot_msg(&msg);
        else if (IS_EMPTY_STRING(g_elink_ctx.dev.token) || IS_EMPTY_STRING(g_elink_ctx.dev.id))
            len = _gen_activate_msg(&msg);
        else
            len = _gen_connect_msg(&msg, g_elink_ctx.dev.token, g_elink_ctx.dev.id);
    }
    else
    {
        len = _gen_heartbeat_msg(&msg);
    }

    ULOG_INFO("(remote) -> %s (%d)\n", msg, len);

    if (len == -1)
    {
        ULOG_ERR("failed to generate boot/activate/connect msg");
        return len;
    }
    else
    {
        obj = cJSON_Parse((char *)msg);

        if (!obj)
        {
            ULOG_ERR("Invalid request (Not json format)\n");
            return -1;
        }
        else
        {
            cJSON_Delete(obj);
        }
    }

    if (!ishb)
    {
        if (!g_elink_ctx.is_bss && IS_EMPTY_STRING(g_elink_ctx.keys.challenge_code))
        {
            en_len = len;
            en_msg = (unsigned char *)strdup((char *)msg);
        }
        else
        {
            en_len = _do_rsa_encrypt(msg, len, &en_msg, g_elink_ctx.keys.public_key);

            if (en_len == 0)
            {
                ULOG_ERR("RSA encrypt failed.\n");
                FREE(msg);
                return en_len;
            }
        }

    }
    else if (_do_aes_ecb_crypt(msg, len, &en_msg, &en_len, g_elink_ctx.keys.server_key, 1) < 0)
    {
        FREE(msg);
        FREE(en_msg);
        return -1;
    }

    _send_remote_msg(en_msg, en_len);
    uloop_timeout_set(&remote_ack_timer, ELINKCC_30S_INTERVAL);
    FREE(msg);

    return 0;
}


void _heartbeat_tmot_cb(struct uloop_timeout *timeout)
{
    _notify_ap_server(&g_elink_ctx.remote.stream, 1);
    uloop_timeout_set(&heartbeat_timer, ELINKCC_100S_INTERVAL);
}


void _remote_ack_tmot_cb(struct uloop_timeout *timeout)
{
    uloop_timeout_set(&remote_disconnect_timer, 0);
    uloop_timeout_set(&remote_connect_timer, ELINKCC_100MS_INTERVAL);
}


void _local_ack_tmot_cb(struct uloop_timeout *timeout)
{
    ULOG_INFO("local ack timeout, disconnect client\n");
    elink_local_notify_state(&g_elink_ctx.local.stream);
}

void _spp_ack_tmot_cb(struct uloop_timeout *timeout)
{
    struct spp_info *p = NULL;
    unsigned char *buf = NULL;
    unsigned char *en_msg = NULL;
    unsigned int buflen = 0;
    int en_len = 0;
    int index = 0;

    p = container_of(timeout, typeof(*p), timer);
   // ULOG_WARN("id %s sequence %d ssp ack time out\n", p->id, p->sequence);

    printf("\n\033[;31m fail:   %s  timeout\033[0m\n",item_array[p->cur_index].item_name);
    

    if (p)
    {
        list_del(&p->list);
        FREE(p->id);
        FREE(p);
        _dump_list(2);
    }
}

int _process_remote_msg(struct ustream *s, struct req_info *p, char *data, unsigned int len)
{
    cJSON *obj = NULL;
    unsigned char *buffer = (unsigned char *)data;
    unsigned char *b64_msg = NULL;
    unsigned char *outbuf = NULL;
    int outlen = 0, b64_len = 0, ret = -1;
    char *acktype = NULL, *rpcmethod = NULL;
    unsigned char *aes_key = NULL;

    b64_len = _do_b64_cmd(buffer, len, &b64_msg, 0);

    if (b64_len == -1)
    {
        ULOG_ERR("Invalid server request (b64 decode failed)\n");
        _bin_print(buffer, len);
        FREE(b64_msg);
        goto done;
    }

    //ULOG_DEBUG("after b64:\n");
    //_bin_print(b64_msg, (unsigned int)b64_len);
    if (g_elink_ctx.is_bss || !IS_EMPTY_STRING(g_elink_ctx.keys.challenge_code))
        aes_key = g_elink_ctx.keys.server_key ? g_elink_ctx.keys.server_key : g_elink_ctx.keys.client_key;

    //ULOG_DEBUG("aes decrypt key is %s (s: %s, c: %s)\n", aes_key,
    //		   g_elink_ctx.keys.server_key, g_elink_ctx.keys.client_key);

    if (aes_key)
    {
        if (_do_aes_ecb_crypt(b64_msg, b64_len, &outbuf, &outlen, aes_key, 0) < 0)
        {
            FREE(b64_msg);
            goto done;
        }
    }
    else
    {
        outbuf = (unsigned char *)strdup((char *)b64_msg);
        outlen = b64_len;
    }

    ULOG_INFO("(remote) <- %s (%d)\n", outbuf, outlen);

    FREE(b64_msg);
    obj = cJSON_Parse((char *)outbuf);

    if (obj == NULL)
    {
        ULOG_ERR("Invalid server request (Not json format)\n");
        _bin_print(outbuf, outlen);
        FREE(outbuf);
        goto done;
    }

    FREE(outbuf);

    _get_string_json_value(obj, "Ack", &acktype);

    if (!acktype)
    {
        _get_string_json_value(obj, "RPCMethod", &rpcmethod);

        if (!rpcmethod)
        {
            int resultack = 0;

            if (_get_int_json_value(obj, "ResultAck", cJSON_Number, &resultack) < 0)
            {

                ULOG_ERR("%d: Unsupported server request\n", __LINE__);
                cJSON_Delete(obj);
                return -1;
            }
            else
            {
                uloop_timeout_cancel(&remote_ack_timer);
                uloop_timeout_set(&remote_disconnect_timer, ELINKCC_100MS_INTERVAL);
                uloop_timeout_set(&remote_connect_timer, ELINKCC_200MS_INTERVAL);
            }
        }
        else if (_strcmp(rpcmethod, "SetPluginParams") == 0)
        {
            ret = _parse_set_plugin_params(obj);
        }
        else if (_strcmp(rpcmethod, "RequestConnectBSS") == 0)
        {
            ret = _parse_request_connect_bss(obj);
        }
        else if (_strcmp(rpcmethod, "ListPlugin") == 0)
        {
            ret = _parse_list_plugin(obj, rpcmethod);
        }
        else
        {
            ret = _parse_unsupported_method(obj, rpcmethod);
        }

        FREE(rpcmethod);
    }
    else
    {

        uloop_timeout_cancel(&remote_ack_timer);

        if (_strcmp(acktype, "Boot") == 0)
            ret = _parse_boot_resp(obj);
        else if (_strcmp(acktype, "GetChallengeCode") == 0)
            ret = _parse_challenge_resp(obj);
        else if (_strcmp(acktype, "Activate") == 0)
            ret = _parse_activate_resp(obj);
        else if (_strcmp(acktype, "Connect") == 0)
            ret = _parse_connect_resp(obj);
        else if (_strcmp(acktype, "Heartbeat") == 0)
            ret = _parse_heartbeat_resp(obj);
        else if (_strcmp(acktype, "PluginNotification") == 0)
            ; /* do nothing */
        else
            ULOG_ERR("Unknown Ack type: %s\n", acktype);

        if (ret == 0)
        {
            g_elink_ctx.retry_count = 0;

            if ((_strcmp(acktype, "Boot") == 0 && _is_same_server()) ||
                    _strcmp(acktype, "Activate") == 0 ||
                    _strcmp(acktype, "GetChallengeCode") == 0)
                _notify_ap_server(s, 0);
            else if (_strcmp(acktype, "Connect") == 0)
                uloop_timeout_set(&heartbeat_timer, ELINKCC_100S_INTERVAL);
        }

        FREE(acktype);
    }

    cJSON_Delete(obj);

done:

    if (p)
    {
        list_del(&p->list);
        FREE(p->raw);
        FREE(p);
        _dump_list(0);
    }

    return ret;
}

unsigned int _get_retry_interval(unsigned int retry_count)
{
    unsigned int interval = 0;
    int min = 0, max = 0;

    /*	0	0-90s
    	1	90-180s
    	2	180-360s
    	3	360-720s
    	4	720-1440s */
    min = (retry_count < 1) ? 0 : 90 * (1 << (retry_count - 1));
    max = 90 * (1 << retry_count);

    interval = _get_random_number(min, max);

#if ENABLE_INTERVAL_DEBUG

    ULOG_DEBUG("DDBBGG interval was %d, DDBBGG modify interval to 1\n", interval);
    interval = 1;

#endif

    ULOG_WARN("(bss: %d)retry count %u, next retry is %u seconds later\n", g_elink_ctx.is_bss, retry_count, interval);

    return interval * 1000;
}

void _get_server_addr(char **serveraddr, unsigned int *serverport)
{
    int idx = 0;

    ULOG_DEBUG("%s: bss %s:%d, abi: %s:%d, retry %d\n", __func__,
               g_elink_ctx.server.bssaddr, g_elink_ctx.server.bssport,
               g_elink_ctx.server.addr, g_elink_ctx.server.port, g_elink_ctx.retry_count);

    *serveraddr = NULL;
    *serverport = 0;

    if (g_elink_ctx.is_bss)
    {
        *serveraddr = g_elink_ctx.server.bssaddr;
        *serverport = g_elink_ctx.server.bssport;
        g_elink_ctx.retry_count = 0;
        g_elink_ctx.retry_cycle = 0;
    }
    else
    {
        if (g_elink_ctx.retry_count == 5)
        {

            for (idx = 0; idx < NUM_OF_BACKUP_SRV; idx++)
            {
                if (g_elink_ctx.server.backup[idx].port == 0)
                    continue;

                if (g_elink_ctx.server.backup[idx].used == 0)
                {
                    *serveraddr = g_elink_ctx.server.backup[idx].addr;
                    *serverport = g_elink_ctx.server.backup[idx].port;
                    g_elink_ctx.server.backup[idx].used = 1;
                    g_elink_ctx.retry_count = 0;
                    break;
                }
            }
        }
        else
        {
            *serveraddr = g_elink_ctx.server.addr;
            *serverport = g_elink_ctx.server.port;
        }
    }

    return;
}


void _free_elink_config(int freeap)
{
    int i = 0;

    FREE(g_elink_ctx.server.bssaddr);
    FREE(g_elink_ctx.server.addr);

    for (i = 0; i < NUM_OF_BACKUP_SRV; i++)
    {
        FREE(g_elink_ctx.server.backup[i].addr);
        g_elink_ctx.server.backup[i].used = 0;
    }

    FREE(g_elink_ctx.dev.id);
    FREE(g_elink_ctx.dev.token);

    if (freeap)
    {
        FREE(g_elink_ctx.ap.mac);
        FREE(g_elink_ctx.ap.vendor);
        FREE(g_elink_ctx.ap.model);
        FREE(g_elink_ctx.ap.swver);
        FREE(g_elink_ctx.ap.hdver);
        FREE(g_elink_ctx.ap.ipaddr);
        FREE(g_elink_ctx.ap.sn);
        FREE(g_elink_ctx.ap.gwmac);
    }
}

static void _update_loglevel(void)
{
    FILE *fp = NULL;
    int level = 0;
    char *strs[] = {"error", "warning", "notice", "info", "debug"};

    fp = fopen(ELINKCC_LOGLEVEL, "r");

    if (fp)
    {
        level = fgetc(fp);

        if (EOF == level)
        {
            fclose(fp);
            return;
        }

        level = level - '0';

        if (level > 4 || level < 0)
            level = 2;

        printf("change loglevel to %s\n", strs[level]);
        ulog_threshold(level + 3); //level -> LOG_XXX

        fclose(fp);
    }
}

int _read_elink_config(struct elink_ctx *config)
{
    cJSON *obj = NULL, *bklist = NULL, *item = NULL;
    int i = 0, j = 0;

    _free_elink_config(0);

    obj = _config_to_jobj(ELINKCC_CONFIG);

    if (!obj)
    {
        config->server.bssport = DEFAULT_BSS_PORT;
        config->server.bssaddr = strdup(DEFAULT_BSS_ADDR);
        g_elink_ctx.is_bootstrap = 1;
        g_elink_ctx.is_bss = 1;

        return -1;
    }

    /*
    {"vendor":"upointech","model":"elinkclt","swver":"1.0","hdver":"0.1",
    "ServerAddr":"192.168.0.6","ServerPort":7777,
    "Backup":[{"ServerAddr":"192.168.0.61","ServerPort":7778},
              {"ServerAddr":"192.168.0.62","ServerPort":7779}],
    "DevToken":"Nm598EAiC4PlZtGSYHD0HPCNDUXnC9Np",
    "DevID":"Nm598EAiC4PlZtGSYHD0HPCNDUXnC9NpzdmqOCPJudGtwYp2"}
    */
    _get_string_json_value(obj, "DevToken", &config->dev.token);
    _get_string_json_value(obj, "DevID", &config->dev.id);

    _get_int_json_value(obj, "BSSPort", cJSON_Number, &config->server.bssport);
    _get_string_json_value(obj, "BSSAddr", &config->server.bssaddr);

    if (config->server.bssport == 0)
        config->server.bssport = DEFAULT_BSS_PORT;

    if (IS_EMPTY_STRING(config->server.bssaddr))
        config->server.bssaddr = strdup(DEFAULT_BSS_ADDR);

    _get_int_json_value(obj, "ServerPort", cJSON_Number, &config->server.port);
    _get_string_json_value(obj, "ServerAddr", &config->server.addr);

    if (IS_EMPTY_STRING(config->server.addr) || !IS_VALID_PORT(config->server.port))
        config->is_bss = 1;

    bklist = cJSON_GetObjectItem(obj, "Backup");

    if (cJSON_IsArray(bklist))
    {
        json_array_foreach(bklist, i, item)
        {
            _get_string_json_value(item, "ServerAddr", &config->server.backup[j].addr);
            _get_int_json_value(item, "ServerPort", cJSON_Number, &config->server.backup[j].port);

            if (!IS_EMPTY_STRING(config->server.backup[j].addr) && IS_VALID_PORT(config->server.backup[j].port))
            {
                ULOG_DEBUG("[%d]: %s:%d\n", j, config->server.backup[j].addr, config->server.backup[j].port);
                j++;
            }

            if (j > (NUM_OF_BACKUP_SRV - 1))
                break;
        }
    }

    cJSON_Delete(obj);

    return 0;

}

void elink_init_ustream(struct elink_ctx *ctx)
{
    memset(&g_elink_ctx, 0, sizeof(struct elink_ctx));

    public_key_init();

    g_elink_ctx.cmd_list.next = &g_elink_ctx.cmd_list;
    g_elink_ctx.cmd_list.prev = &g_elink_ctx.cmd_list;

    g_elink_ctx.req_list.next = &g_elink_ctx.req_list;
    g_elink_ctx.req_list.prev = &g_elink_ctx.req_list;

    g_elink_ctx.spp_list.next = &g_elink_ctx.spp_list;
    g_elink_ctx.spp_list.prev = &g_elink_ctx.spp_list;

    g_elink_ctx.local.stream.string_data = false;
    g_elink_ctx.local.stream.notify_read = elink_local_read_cb;
    g_elink_ctx.local.stream.notify_state = elink_local_notify_state;

    g_elink_ctx.remote.stream.string_data = false;
    g_elink_ctx.remote.stream.notify_read = elink_remote_read_cb;
    g_elink_ctx.remote.stream.notify_state = elink_remote_notify_state;
}


int elink_cloud_client(void)
{
    char portstr[8] = {0};
    int cloudclient_fd = UNKNOWN_FD, i = 0;

    if (!g_elink_ctx.curr_srv)
        _get_server_addr(&g_elink_ctx.curr_srv, &g_elink_ctx.curr_port);

    ULOG_DEBUG("current server %s:%d\n", g_elink_ctx.curr_srv, g_elink_ctx.curr_port);

    if (IS_EMPTY_STRING(g_elink_ctx.curr_srv) || (g_elink_ctx.curr_port == 0))
    {
        g_elink_ctx.retry_cycle++;
        uloop_timeout_set(&remote_disconnect_timer, 0);

        if (g_elink_ctx.retry_cycle % 3 == 0)
        {
            ULOG_INFO("re-connect bss server\n");
            g_elink_ctx.is_bss = 1;
            /* re-connect bss to get new ability server */
            uloop_timeout_set(&remote_connect_timer, ELINKCC_200MS_INTERVAL);

        }
        else
        {
            ULOG_INFO("re-connect ability server after %d seconds\n", ELINKCC_150M_INTERVAL / 1000);
            g_elink_ctx.retry_count = 0;

            for (i = 0; i < NUM_OF_BACKUP_SRV; i++)
                g_elink_ctx.server.backup[i].used = 0;

            uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
        }

        return 0;
    }

    sprintf(portstr, "%u", g_elink_ctx.curr_port);
    cloudclient_fd = usock(USOCK_TCP | USOCK_NONBLOCK, g_elink_ctx.curr_srv, portstr);

    if (cloudclient_fd > 0)
    {
        //ULOG_DEBUG("elink cloudclient fd: %d\n", cloudclient_fd);

        ustream_fd_init(&g_elink_ctx.remote, cloudclient_fd);

        _notify_ap_server(&g_elink_ctx.remote.stream, 0);
    }
    else
    {
        ULOG_ERR("create socket failed: %m\n", errno);
        if (g_elink_ctx.retry_count == 5)
            g_elink_ctx.retry_count = 0;
        uloop_timeout_set(&remote_connect_timer, _get_retry_interval(g_elink_ctx.retry_count++));
    }

#if 0
    else
    {
        ULOG_ERR("***********failed to connect ap server %s:%d, retry_count %d\n",
                 g_elink_ctx.curr_srv, g_elink_ctx.curr_port, g_elink_ctx.retry_count);

        uloop_timeout_set(&remote_disconnect_timer, 0);
        uloop_timeout_set(&remote_connect_timer, _get_retry_interval(g_elink_ctx.retry_count));
        g_elink_ctx.retry_count++;

        if (g_elink_ctx.retry_count == 5)
        {
            /* re-select bss/ability server */
            g_elink_ctx.curr_srv = NULL;

            if (g_elink_ctx.is_bss)
            {
                ULOG_INFO("re-connect bss server after %d seconds\n", interval / 1000);
                uloop_timeout_set(&remote_connect_timer, interval);
            }
        }
    }

#endif
    return 0;
}

int elink_notification(cJSON *obj)
{
    int len = 0, b64len = 0, en_len = 0;
    unsigned char *b64buf = NULL, *outbuf = NULL, *en_msg = NULL;
    char *jstr = NULL, *time = NULL, *id = NULL;

    if (IS_EMPTY_STRING(g_elink_ctx.keys.server_key))
    {
        ULOG_WARN("ap server not connected, ignore this dev_report msg\n");
        return 0;
    }


    jstr = cJSON_PrintUnformatted(obj);

    if (!jstr)
    {
        ULOG_ERR("%s: invalid json obj\n", __func__);
        return -1;
    }

    b64len = _do_b64_cmd((unsigned char *)jstr, strlen(jstr), &b64buf, 1);
    _get_sys_time(&time);
    _get_uuid_string(&id);

    if (b64len > 0 && time)
    {

        len = asprintf((char **)&outbuf, "{\"RPCMethod\":\"PluginNotification\",\"ID\":\"%s\","
                       "\"Plugin_Name\":\"%s\",\"Version\":\"%s\",\"Time\":\"%s\",\"Message\":\"%s\"}",
                       id, ELINK_PLUGIN_NAME, g_elink_ctx.ap.swver, time, b64buf);

    }
    else
    {
        ULOG_ERR("%d: failed to generate PluginNotification msg\n", __LINE__);
    }

    if (len > 0)
    {
        ULOG_INFO("(remote) -> %s (%d)\n", outbuf, len);

        if (_do_aes_ecb_crypt(outbuf, len, &en_msg, &en_len, g_elink_ctx.keys.server_key, 1) < 0)
            goto done;

        _send_remote_msg(en_msg, en_len);
        uloop_timeout_set(&remote_ack_timer, ELINKCC_30S_INTERVAL);
    }
    else
    {
        ULOG_ERR("%d: failed to generate msg\n", __LINE__);
    }

done:

    cJSON_free(jstr);
    FREE(time);
    FREE(id);
    FREE(outbuf);
    FREE(b64buf);
    return 0;
}

void _remote_connect_cb(struct uloop_timeout *timeout)
{
    ULOG_DEBUG("%s: %d\n", __func__, __LINE__);
    elink_cloud_client();
}

void _local_action_cb(struct uloop_timeout *timeout)
{
    struct cmd_info *c = NULL, *d = NULL;

    list_for_each_entry_safe(c, d, &g_elink_ctx.cmd_list, list)
    {
        _process_local_msg(&g_elink_ctx.local.stream, c, c->content, c->len);
    }
}




void _remote_action_cb(struct uloop_timeout *timeout)
{
    struct req_info *p = NULL, *q = NULL;

    list_for_each_entry_safe(p, q, &g_elink_ctx.req_list, list)
    {
        _process_remote_msg(&g_elink_ctx.remote.stream, p, p->raw, p->len);
    }
}


void _remote_disconnect_cb(struct uloop_timeout *timeout)
{
    struct req_info *p = NULL, *q = NULL;
    struct cmd_info *c = NULL, *d = NULL;
    struct spp_info *e = NULL, *f = NULL;

    list_for_each_entry_safe(c, d, &g_elink_ctx.cmd_list, list)
    {
        list_del(&c->list);
        FREE(c->content);
        FREE(c);
    }

    list_for_each_entry_safe(p, q, &g_elink_ctx.req_list, list)
    {
        list_del(&p->list);
        FREE(p->raw);
        FREE(p);
    }

    list_for_each_entry_safe(e, f, &g_elink_ctx.spp_list, list)
    {
        list_del(&e->list);
        uloop_timeout_cancel(&e->timer);
        FREE(e->id);
        FREE(e);
    }

    if (g_elink_ctx.remote.fd.fd > 0)
    {
        ustream_free(&g_elink_ctx.remote.stream);
        close(g_elink_ctx.remote.fd.fd);
        ULOG_DEBUG("%s: close tcp fd %d\n", __func__, g_elink_ctx.remote.fd.fd);
        g_elink_ctx.remote.fd.fd = UNKNOWN_FD;
    }

    FREE(g_elink_ctx.keys.server_key);
    FREE(g_elink_ctx.keys.client_key);
    FREE(g_elink_ctx.keys.challenge_code);

    uloop_timeout_cancel(&remote_ack_timer);
    uloop_timeout_cancel(&heartbeat_timer);
}


enum elink_msg_type _get_cb_by_type(char *type, msg_handler *cb, int *timer, int *isdh)
{
    enum elink_msg_type emtype = EMT_UNKNOWN;

    if (_strcmp(type, "keyngreq") == 0)
    {
        emtype = EMT_KEYNGREQ;
        *timer = ELINK_TIMEOUT_5S;
        *cb = _handle_keyngreq;
    }
    else if (_strcmp(type, "dh") == 0)
    {
        emtype = EMT_DH;
        *timer = ELINK_TIMEOUT_5S;
        *isdh = 1;
        *cb = _handle_dh;
        uloop_timeout_cancel(&local_ack_timer);
    }
    else if (_strcmp(type, "ecdh") == 0)
    {
        emtype = EMT_ECDH;
        *timer = ELINK_TIMEOUT_5S;
        *isdh = 1;
        *cb = _handle_ecdh;
        uloop_timeout_cancel(&local_ack_timer);
    }
    else if (_strcmp(type, "dev_reg") == 0)
    {
        emtype = EMT_DEVREG;
        *timer = ELINK_TIMEOUT_20S;
        *cb = _handle_dev_reg;
        uloop_timeout_cancel(&local_ack_timer);
    }
    else if (_strcmp(type, "keepalive") == 0)
    {
        emtype = EMT_KEEPALIVE;
        *timer = ELINK_TIMEOUT_20S;
        *cb = _handle_keepalive;
    }
    else if (_strcmp(type, "ack") == 0)
    {
        emtype = EMT_ACK;
        *cb = _handle_ack;
    }
    else if (_strcmp(type, "status") == 0)
    {
        emtype = EMT_STATUS;
        *cb = _handle_status;
    }
    else if (_strcmp(type, "dev_report") == 0)
    {
        emtype = EMT_DEVREPORT;
        *cb = _handle_dev_report;
    }
    else if (_strcmp(type, "rssiinfo") == 0)
    {
        emtype = EMT_DEVREPORT;
        *cb = _handle_rssiinfo_report;
    }
    else if (_strcmp(type, "cfg") == 0)
    {
        emtype = EMT_CFG;
        *cb = _handle_roaming_report;
    }
    else if (_strcmp(type, "wan_report") == 0)
    {
        emtype = EMT_WANREPORT;
        *cb = _handle_wan_report;
    }
    else
    {
        *cb = NULL;
        ULOG_WARN("%s: not supported yet\n", type);
    }

    return emtype;
}

int _process_local_msg(struct ustream *s, struct cmd_info *c, char *data, unsigned int len)
{
    int ret = -1;
    char *type = NULL;
    cJSON *obj = NULL;
    unsigned char *rsp_buf = NULL;

    unsigned char *buffer = (unsigned char *)data;
    unsigned char *outbuf = NULL;
    enum elink_msg_type emtype = EMT_UNKNOWN;
    msg_handler cb = NULL;
    int outlen = 0, cnt = 0, timer = 0, isdh = 0;

    if (g_elink_ctx.keys.shared_key)
    {

        if (_do_aes_cbc_crypt(buffer, len, &outbuf, &outlen, g_elink_ctx.keys.shared_key, 0) > 0)
        {
            //if (strstr((char *)outbuf, "keepalive") == NULL)
           //ULOG_DEBUG("(server) <- %s (%d)\n", outbuf, outlen);

            obj = cJSON_Parse((char *)outbuf);
        }

        FREE(outbuf);

    }
    else
    {
        buffer[len] = '\0';
       // ULOG_DEBUG("(server) <- %s (%d)\n", buffer, len);
        obj = cJSON_Parse((char *)buffer);
    }

    if (NULL == obj)
    {
        //ULOG_ERR("Invalid client request (Not json format).\n");
        uloop_timeout_set(&local_ack_timer, ELINKCC_200MS_INTERVAL);
        goto done;
    }

    ret = _get_string_json_value(obj, "type", &type);

    if (ret < 0)
    {
       ULOG_DEBUG("elink server: No type\n");
        goto done;
    }

    emtype = _get_cb_by_type(type, &cb, &timer, &isdh);

    if (emtype == EMT_UNKNOWN || cb == NULL)
    {
        goto done;
    }

	
	if(_is_ack_type(emtype))
	{
		outbuf = cJSON_Print(obj);
		//ULOG_DEBUG("(server) <- %s \n", outbuf);
		FREE(outbuf);
	}

       
    cnt = cb(obj, c, &rsp_buf);

    if (!_is_ack_type(emtype))
    {

        if (cnt <= 0)
        {
            ULOG_ERR("handle %s failed [-]\n", type);
            goto done;
        }

       // if (emtype != EMT_KEEPALIVE)
           // ULOG_DEBUG("(local) -> %s (%d)\n", rsp_buf, cnt);

        ret = _send_local_msg(rsp_buf, cnt, isdh);

        if (ret < 0)
        {
            ULOG_ERR("send to elink client failed\n");
            goto done;
        }
        else if (timer)
        {
            uloop_timeout_set(&local_ack_timer, timer * 1000);
        }

        if (EMT_DEVREG == emtype)
        {
            //_read_elink_config(&g_elink_ctx);
	    //�˴�Ҳ��ͬ���ģ�ֻҪע����У�����cloud��client
          //  elink_cloud_client();
          //�޸Ĵ˴���ʼ���Գ���
          	start_test_process();
        }
        else if (EMT_DEVREPORT == emtype)
        {
        	//ֻ����client�Ŀͻ����ϱ��������д���
            //elink_notification(obj);
        }
    }

done:

    if (c)
    {
        list_del(&c->list);
        FREE(c->content);
        FREE(c);
        _dump_list(1);
    }

    FREE(rsp_buf);
    FREE(type);
    cJSON_Delete(obj);

    return ret;
}


static void elink_local_read_cb(struct ustream *s, int bytes)
{
    _elink_internal_read(s, bytes, ELINK_HEADER_LEN, 0, NULL, _add_local_msg_to_list);
}


static void elink_local_notify_state(struct ustream *s)
{
    struct ustream_fd *ufd = container_of(s, struct ustream_fd, stream);

    ULOG_WARN("Elink socket client exit, close unix fd %d\n", ufd->fd.fd);
    ustream_free(s);
    close(ufd->fd.fd);
    ufd->fd.fd = UNKNOWN_FD;

    uloop_timeout_cancel(&local_ack_timer);

    _remote_disconnect_cb(NULL);
    uloop_timeout_cancel(&remote_connect_timer);

    FREE(g_elink_ctx.keys.shared_key);
    FREE(g_elink_ctx.msg);
    g_elink_ctx.curr_srv = NULL;
    g_elink_ctx.retry_count = 0;
    g_elink_ctx.retry_cycle = 0;

    _free_elink_config(1);

    elink_unix_server();
}

static void elink_remote_notify_state(struct ustream *s)
{
    _remote_disconnect_cb(NULL);

    if (g_elink_ctx.retry_count == 5)
    {
        /* re-select bss/ability server */
        g_elink_ctx.curr_srv = NULL;

        if (g_elink_ctx.is_bss)
        {
            ULOG_INFO("re-connect bss server after %d seconds\n", ELINKCC_150M_INTERVAL / 1000);
            uloop_timeout_set(&remote_connect_timer, ELINKCC_150M_INTERVAL);
        }
        else
        {
            uloop_timeout_set(&remote_connect_timer, ELINKCC_100MS_INTERVAL);
        }
    }
    else
    {
        uloop_timeout_set(&remote_connect_timer, _get_retry_interval(g_elink_ctx.retry_count));
        g_elink_ctx.retry_count++;
    }
}


static void elink_local_connection(struct uloop_fd *ufd, unsigned int events)
{
    struct sockaddr_in sin;
    unsigned int sl = sizeof(struct sockaddr_in);
    int clientfd = 0;

    clientfd = accept(ufd->fd, (struct sockaddr *) &sin, &sl);

    if (clientfd == -1)
    {
        ULOG_ERR("elink unix client accept error\n");
        return;
    }

    ustream_fd_init(&g_elink_ctx.local, clientfd);
    

    ULOG_DEBUG("New elink clinet come in  fd: %d\n", clientfd);


    ULOG_DEBUG("close elink unix server fd: %d\n", g_elink_ctx.srv_fd.fd);
    uloop_fd_delete(&g_elink_ctx.srv_fd);
    close(g_elink_ctx.srv_fd.fd);
    g_elink_ctx.srv_fd.fd = UNKNOWN_FD;
}

void _elink_sdk_sig_cb(int sig)
{
    ULOG_DEBUG("got sig %d [%s]\n", sig, strsignal(sig));

    if (SIGINT == sig || SIGTERM == sig)
    {

        _remote_disconnect_cb(NULL);
        FREE(g_elink_ctx.keys.shared_key);
        FREE(g_elink_ctx.keys.public_key);

        _free_elink_config(1);

        if (g_elink_ctx.local.fd.fd > 0)
        {
            close(g_elink_ctx.local.fd.fd);
            ustream_free(&g_elink_ctx.local.stream);
        }

        exit(0);
    }
    else if (SIGUSR1 == sig)
    {
        /* change log level */
        _update_loglevel();
    }
}

void elink_setup_signals(void)
{
    _set_signal_handler(SIGTERM, _elink_sdk_sig_cb);
    _set_signal_handler(SIGINT, _elink_sdk_sig_cb);
    _set_signal_handler(SIGUSR1, _elink_sdk_sig_cb);
}


static void elink_unix_server(void)
{
    unlink(ELINK_UNIX_SOCKET);

#define USE_LOCAL_TCP_SERVER 1

#if USE_LOCAL_TCP_SERVER
    g_elink_ctx.srv_fd.fd = usock(USOCK_TCP | USOCK_SERVER, ELINK_SERVER_IP, ELINK_SERVER_PORT);
#else
    g_elink_ctx.srv_fd.fd = usock(USOCK_UNIX | USOCK_SERVER | USOCK_NONBLOCK, ELINK_UNIX_SOCKET, NULL);
#endif
    g_elink_ctx.srv_fd.cb = elink_local_connection;

    if (g_elink_ctx.srv_fd.fd > 0)
    {
        ULOG_DEBUG("elink unix server fd: %d\n", g_elink_ctx.srv_fd.fd);
        uloop_fd_add(&g_elink_ctx.srv_fd, ULOOP_READ);
    }
    else
    {
        ULOG_ERR("elink unix server socket error, %s\n", strerror(errno));
        exit(0);
    }
}

int main(int argc, char **argv)
{

    if (argc == 2 && _strcmp(argv[1], "version") == 0)
    {
        printf("SDK Revision: R%s\n", STR(SVN_REVISION));
        printf("SDK build time: %s\n", STR(BUILD_TIME));
        return 0;
    }
    else if (argc > 1)
    {
        return 0;
    }

    ulog_open(ULOG_STDIO, LOG_USER, ELINK_CC_PREFIX);

    uloop_init();

    init_test_config();
	
    elink_init_ustream(&g_elink_ctx);

    elink_setup_signals();

    elink_unix_server();

    uloop_run();

    uloop_done();

    ulog_close();

    return 0;
}
